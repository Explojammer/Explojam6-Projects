gdjs.level_321Code = {};
gdjs.level_321Code.localVariables = [];
gdjs.level_321Code.GDsettings_9595iconObjects1= [];
gdjs.level_321Code.GDsettings_9595iconObjects2= [];
gdjs.level_321Code.GDsettings_9595iconObjects3= [];
gdjs.level_321Code.GDsettings_9595iconObjects4= [];
gdjs.level_321Code.GDsettings_9595iconObjects5= [];
gdjs.level_321Code.GDsettingsPageOutlineObjects1= [];
gdjs.level_321Code.GDsettingsPageOutlineObjects2= [];
gdjs.level_321Code.GDsettingsPageOutlineObjects3= [];
gdjs.level_321Code.GDsettingsPageOutlineObjects4= [];
gdjs.level_321Code.GDsettingsPageOutlineObjects5= [];
gdjs.level_321Code.GDmstrVolTextObjects1= [];
gdjs.level_321Code.GDmstrVolTextObjects2= [];
gdjs.level_321Code.GDmstrVolTextObjects3= [];
gdjs.level_321Code.GDmstrVolTextObjects4= [];
gdjs.level_321Code.GDmstrVolTextObjects5= [];
gdjs.level_321Code.GDmstrVolSliderObjects1= [];
gdjs.level_321Code.GDmstrVolSliderObjects2= [];
gdjs.level_321Code.GDmstrVolSliderObjects3= [];
gdjs.level_321Code.GDmstrVolSliderObjects4= [];
gdjs.level_321Code.GDmstrVolSliderObjects5= [];
gdjs.level_321Code.GDmstrVolValueObjects1= [];
gdjs.level_321Code.GDmstrVolValueObjects2= [];
gdjs.level_321Code.GDmstrVolValueObjects3= [];
gdjs.level_321Code.GDmstrVolValueObjects4= [];
gdjs.level_321Code.GDmstrVolValueObjects5= [];
gdjs.level_321Code.GDbgMusicVolTextObjects1= [];
gdjs.level_321Code.GDbgMusicVolTextObjects2= [];
gdjs.level_321Code.GDbgMusicVolTextObjects3= [];
gdjs.level_321Code.GDbgMusicVolTextObjects4= [];
gdjs.level_321Code.GDbgMusicVolTextObjects5= [];
gdjs.level_321Code.GDsndEfctsVolTextObjects1= [];
gdjs.level_321Code.GDsndEfctsVolTextObjects2= [];
gdjs.level_321Code.GDsndEfctsVolTextObjects3= [];
gdjs.level_321Code.GDsndEfctsVolTextObjects4= [];
gdjs.level_321Code.GDsndEfctsVolTextObjects5= [];
gdjs.level_321Code.GDsndEffctsVolSliderObjects1= [];
gdjs.level_321Code.GDsndEffctsVolSliderObjects2= [];
gdjs.level_321Code.GDsndEffctsVolSliderObjects3= [];
gdjs.level_321Code.GDsndEffctsVolSliderObjects4= [];
gdjs.level_321Code.GDsndEffctsVolSliderObjects5= [];
gdjs.level_321Code.GDbgMusicVolSliderObjects1= [];
gdjs.level_321Code.GDbgMusicVolSliderObjects2= [];
gdjs.level_321Code.GDbgMusicVolSliderObjects3= [];
gdjs.level_321Code.GDbgMusicVolSliderObjects4= [];
gdjs.level_321Code.GDbgMusicVolSliderObjects5= [];
gdjs.level_321Code.GDsndEffectsVolValueObjects1= [];
gdjs.level_321Code.GDsndEffectsVolValueObjects2= [];
gdjs.level_321Code.GDsndEffectsVolValueObjects3= [];
gdjs.level_321Code.GDsndEffectsVolValueObjects4= [];
gdjs.level_321Code.GDsndEffectsVolValueObjects5= [];
gdjs.level_321Code.GDbgMusicVolValueObjects1= [];
gdjs.level_321Code.GDbgMusicVolValueObjects2= [];
gdjs.level_321Code.GDbgMusicVolValueObjects3= [];
gdjs.level_321Code.GDbgMusicVolValueObjects4= [];
gdjs.level_321Code.GDbgMusicVolValueObjects5= [];
gdjs.level_321Code.GDexitButtonObjects1= [];
gdjs.level_321Code.GDexitButtonObjects2= [];
gdjs.level_321Code.GDexitButtonObjects3= [];
gdjs.level_321Code.GDexitButtonObjects4= [];
gdjs.level_321Code.GDexitButtonObjects5= [];
gdjs.level_321Code.GDShadedDarkJoystickObjects1= [];
gdjs.level_321Code.GDShadedDarkJoystickObjects2= [];
gdjs.level_321Code.GDShadedDarkJoystickObjects3= [];
gdjs.level_321Code.GDShadedDarkJoystickObjects4= [];
gdjs.level_321Code.GDShadedDarkJoystickObjects5= [];
gdjs.level_321Code.GDJumpObjects1= [];
gdjs.level_321Code.GDJumpObjects2= [];
gdjs.level_321Code.GDJumpObjects3= [];
gdjs.level_321Code.GDJumpObjects4= [];
gdjs.level_321Code.GDJumpObjects5= [];
gdjs.level_321Code.GDSlideObjects1= [];
gdjs.level_321Code.GDSlideObjects2= [];
gdjs.level_321Code.GDSlideObjects3= [];
gdjs.level_321Code.GDSlideObjects4= [];
gdjs.level_321Code.GDSlideObjects5= [];
gdjs.level_321Code.GDlaternObjects1= [];
gdjs.level_321Code.GDlaternObjects2= [];
gdjs.level_321Code.GDlaternObjects3= [];
gdjs.level_321Code.GDlaternObjects4= [];
gdjs.level_321Code.GDlaternObjects5= [];
gdjs.level_321Code.GDarrowObjects1= [];
gdjs.level_321Code.GDarrowObjects2= [];
gdjs.level_321Code.GDarrowObjects3= [];
gdjs.level_321Code.GDarrowObjects4= [];
gdjs.level_321Code.GDarrowObjects5= [];
gdjs.level_321Code.GDMaleCharacter10Objects1= [];
gdjs.level_321Code.GDMaleCharacter10Objects2= [];
gdjs.level_321Code.GDMaleCharacter10Objects3= [];
gdjs.level_321Code.GDMaleCharacter10Objects4= [];
gdjs.level_321Code.GDMaleCharacter10Objects5= [];
gdjs.level_321Code.GDFlameObjects1= [];
gdjs.level_321Code.GDFlameObjects2= [];
gdjs.level_321Code.GDFlameObjects3= [];
gdjs.level_321Code.GDFlameObjects4= [];
gdjs.level_321Code.GDFlameObjects5= [];
gdjs.level_321Code.GDExplosion1Objects1= [];
gdjs.level_321Code.GDExplosion1Objects2= [];
gdjs.level_321Code.GDExplosion1Objects3= [];
gdjs.level_321Code.GDExplosion1Objects4= [];
gdjs.level_321Code.GDExplosion1Objects5= [];
gdjs.level_321Code.GDaimLineObjects1= [];
gdjs.level_321Code.GDaimLineObjects2= [];
gdjs.level_321Code.GDaimLineObjects3= [];
gdjs.level_321Code.GDaimLineObjects4= [];
gdjs.level_321Code.GDaimLineObjects5= [];
gdjs.level_321Code.GDmousePosObjects1= [];
gdjs.level_321Code.GDmousePosObjects2= [];
gdjs.level_321Code.GDmousePosObjects3= [];
gdjs.level_321Code.GDmousePosObjects4= [];
gdjs.level_321Code.GDmousePosObjects5= [];
gdjs.level_321Code.GDlineObjects1= [];
gdjs.level_321Code.GDlineObjects2= [];
gdjs.level_321Code.GDlineObjects3= [];
gdjs.level_321Code.GDlineObjects4= [];
gdjs.level_321Code.GDlineObjects5= [];
gdjs.level_321Code.GDground1Objects1= [];
gdjs.level_321Code.GDground1Objects2= [];
gdjs.level_321Code.GDground1Objects3= [];
gdjs.level_321Code.GDground1Objects4= [];
gdjs.level_321Code.GDground1Objects5= [];
gdjs.level_321Code.GDZombieObjects1= [];
gdjs.level_321Code.GDZombieObjects2= [];
gdjs.level_321Code.GDZombieObjects3= [];
gdjs.level_321Code.GDZombieObjects4= [];
gdjs.level_321Code.GDZombieObjects5= [];
gdjs.level_321Code.GDSpiderObjects1= [];
gdjs.level_321Code.GDSpiderObjects2= [];
gdjs.level_321Code.GDSpiderObjects3= [];
gdjs.level_321Code.GDSpiderObjects4= [];
gdjs.level_321Code.GDSpiderObjects5= [];
gdjs.level_321Code.GDbatObjects1= [];
gdjs.level_321Code.GDbatObjects2= [];
gdjs.level_321Code.GDbatObjects3= [];
gdjs.level_321Code.GDbatObjects4= [];
gdjs.level_321Code.GDbatObjects5= [];
gdjs.level_321Code.GDcheckpointObjects1= [];
gdjs.level_321Code.GDcheckpointObjects2= [];
gdjs.level_321Code.GDcheckpointObjects3= [];
gdjs.level_321Code.GDcheckpointObjects4= [];
gdjs.level_321Code.GDcheckpointObjects5= [];
gdjs.level_321Code.GDtransistionObjects1= [];
gdjs.level_321Code.GDtransistionObjects2= [];
gdjs.level_321Code.GDtransistionObjects3= [];
gdjs.level_321Code.GDtransistionObjects4= [];
gdjs.level_321Code.GDtransistionObjects5= [];
gdjs.level_321Code.GDdeathCountTextObjects1= [];
gdjs.level_321Code.GDdeathCountTextObjects2= [];
gdjs.level_321Code.GDdeathCountTextObjects3= [];
gdjs.level_321Code.GDdeathCountTextObjects4= [];
gdjs.level_321Code.GDdeathCountTextObjects5= [];
gdjs.level_321Code.GDkillLineObjects1= [];
gdjs.level_321Code.GDkillLineObjects2= [];
gdjs.level_321Code.GDkillLineObjects3= [];
gdjs.level_321Code.GDkillLineObjects4= [];
gdjs.level_321Code.GDkillLineObjects5= [];
gdjs.level_321Code.GDheartBarObjects1= [];
gdjs.level_321Code.GDheartBarObjects2= [];
gdjs.level_321Code.GDheartBarObjects3= [];
gdjs.level_321Code.GDheartBarObjects4= [];
gdjs.level_321Code.GDheartBarObjects5= [];
gdjs.level_321Code.GDlanternFuelBarObjects1= [];
gdjs.level_321Code.GDlanternFuelBarObjects2= [];
gdjs.level_321Code.GDlanternFuelBarObjects3= [];
gdjs.level_321Code.GDlanternFuelBarObjects4= [];
gdjs.level_321Code.GDlanternFuelBarObjects5= [];
gdjs.level_321Code.GDzombieHealthObjects1= [];
gdjs.level_321Code.GDzombieHealthObjects2= [];
gdjs.level_321Code.GDzombieHealthObjects3= [];
gdjs.level_321Code.GDzombieHealthObjects4= [];
gdjs.level_321Code.GDzombieHealthObjects5= [];
gdjs.level_321Code.GDdamageObjects1= [];
gdjs.level_321Code.GDdamageObjects2= [];
gdjs.level_321Code.GDdamageObjects3= [];
gdjs.level_321Code.GDdamageObjects4= [];
gdjs.level_321Code.GDdamageObjects5= [];
gdjs.level_321Code.GDlaywerObjects1= [];
gdjs.level_321Code.GDlaywerObjects2= [];
gdjs.level_321Code.GDlaywerObjects3= [];
gdjs.level_321Code.GDlaywerObjects4= [];
gdjs.level_321Code.GDlaywerObjects5= [];
gdjs.level_321Code.GDbreifcaseObjects1= [];
gdjs.level_321Code.GDbreifcaseObjects2= [];
gdjs.level_321Code.GDbreifcaseObjects3= [];
gdjs.level_321Code.GDbreifcaseObjects4= [];
gdjs.level_321Code.GDbreifcaseObjects5= [];
gdjs.level_321Code.GDfallingPlatformObjects1= [];
gdjs.level_321Code.GDfallingPlatformObjects2= [];
gdjs.level_321Code.GDfallingPlatformObjects3= [];
gdjs.level_321Code.GDfallingPlatformObjects4= [];
gdjs.level_321Code.GDfallingPlatformObjects5= [];
gdjs.level_321Code.GDlaywerHealthBarObjects1= [];
gdjs.level_321Code.GDlaywerHealthBarObjects2= [];
gdjs.level_321Code.GDlaywerHealthBarObjects3= [];
gdjs.level_321Code.GDlaywerHealthBarObjects4= [];
gdjs.level_321Code.GDlaywerHealthBarObjects5= [];
gdjs.level_321Code.GDbarn_9595interior_95951Objects1= [];
gdjs.level_321Code.GDbarn_9595interior_95951Objects2= [];
gdjs.level_321Code.GDbarn_9595interior_95951Objects3= [];
gdjs.level_321Code.GDbarn_9595interior_95951Objects4= [];
gdjs.level_321Code.GDbarn_9595interior_95951Objects5= [];
gdjs.level_321Code.GDsky1Objects1= [];
gdjs.level_321Code.GDsky1Objects2= [];
gdjs.level_321Code.GDsky1Objects3= [];
gdjs.level_321Code.GDsky1Objects4= [];
gdjs.level_321Code.GDsky1Objects5= [];
gdjs.level_321Code.GDlavaObjects1= [];
gdjs.level_321Code.GDlavaObjects2= [];
gdjs.level_321Code.GDlavaObjects3= [];
gdjs.level_321Code.GDlavaObjects4= [];
gdjs.level_321Code.GDlavaObjects5= [];
gdjs.level_321Code.GDspiderHealthObjects1= [];
gdjs.level_321Code.GDspiderHealthObjects2= [];
gdjs.level_321Code.GDspiderHealthObjects3= [];
gdjs.level_321Code.GDspiderHealthObjects4= [];
gdjs.level_321Code.GDspiderHealthObjects5= [];
gdjs.level_321Code.GDWillyObjects1= [];
gdjs.level_321Code.GDWillyObjects2= [];
gdjs.level_321Code.GDWillyObjects3= [];
gdjs.level_321Code.GDWillyObjects4= [];
gdjs.level_321Code.GDWillyObjects5= [];
gdjs.level_321Code.GDWillyHeadObjects1= [];
gdjs.level_321Code.GDWillyHeadObjects2= [];
gdjs.level_321Code.GDWillyHeadObjects3= [];
gdjs.level_321Code.GDWillyHeadObjects4= [];
gdjs.level_321Code.GDWillyHeadObjects5= [];
gdjs.level_321Code.GDWillyLowerRightLegObjects1= [];
gdjs.level_321Code.GDWillyLowerRightLegObjects2= [];
gdjs.level_321Code.GDWillyLowerRightLegObjects3= [];
gdjs.level_321Code.GDWillyLowerRightLegObjects4= [];
gdjs.level_321Code.GDWillyLowerRightLegObjects5= [];
gdjs.level_321Code.GDWillyUpperRightLegObjects1= [];
gdjs.level_321Code.GDWillyUpperRightLegObjects2= [];
gdjs.level_321Code.GDWillyUpperRightLegObjects3= [];
gdjs.level_321Code.GDWillyUpperRightLegObjects4= [];
gdjs.level_321Code.GDWillyUpperRightLegObjects5= [];
gdjs.level_321Code.GDWillyUpperLeftLegObjects1= [];
gdjs.level_321Code.GDWillyUpperLeftLegObjects2= [];
gdjs.level_321Code.GDWillyUpperLeftLegObjects3= [];
gdjs.level_321Code.GDWillyUpperLeftLegObjects4= [];
gdjs.level_321Code.GDWillyUpperLeftLegObjects5= [];
gdjs.level_321Code.GDWillyLowerLeftLegObjects1= [];
gdjs.level_321Code.GDWillyLowerLeftLegObjects2= [];
gdjs.level_321Code.GDWillyLowerLeftLegObjects3= [];
gdjs.level_321Code.GDWillyLowerLeftLegObjects4= [];
gdjs.level_321Code.GDWillyLowerLeftLegObjects5= [];
gdjs.level_321Code.GDrock_9595bg_95951Objects1= [];
gdjs.level_321Code.GDrock_9595bg_95951Objects2= [];
gdjs.level_321Code.GDrock_9595bg_95951Objects3= [];
gdjs.level_321Code.GDrock_9595bg_95951Objects4= [];
gdjs.level_321Code.GDrock_9595bg_95951Objects5= [];
gdjs.level_321Code.GDrock_9595bg_95952Objects1= [];
gdjs.level_321Code.GDrock_9595bg_95952Objects2= [];
gdjs.level_321Code.GDrock_9595bg_95952Objects3= [];
gdjs.level_321Code.GDrock_9595bg_95952Objects4= [];
gdjs.level_321Code.GDrock_9595bg_95952Objects5= [];
gdjs.level_321Code.GDborder_95951Objects1= [];
gdjs.level_321Code.GDborder_95951Objects2= [];
gdjs.level_321Code.GDborder_95951Objects3= [];
gdjs.level_321Code.GDborder_95951Objects4= [];
gdjs.level_321Code.GDborder_95951Objects5= [];
gdjs.level_321Code.GDwoodenPlatformObjects1= [];
gdjs.level_321Code.GDwoodenPlatformObjects2= [];
gdjs.level_321Code.GDwoodenPlatformObjects3= [];
gdjs.level_321Code.GDwoodenPlatformObjects4= [];
gdjs.level_321Code.GDwoodenPlatformObjects5= [];
gdjs.level_321Code.GDboxObjects1= [];
gdjs.level_321Code.GDboxObjects2= [];
gdjs.level_321Code.GDboxObjects3= [];
gdjs.level_321Code.GDboxObjects4= [];
gdjs.level_321Code.GDboxObjects5= [];
gdjs.level_321Code.GDfanObjects1= [];
gdjs.level_321Code.GDfanObjects2= [];
gdjs.level_321Code.GDfanObjects3= [];
gdjs.level_321Code.GDfanObjects4= [];
gdjs.level_321Code.GDfanObjects5= [];
gdjs.level_321Code.GDchestObjects1= [];
gdjs.level_321Code.GDchestObjects2= [];
gdjs.level_321Code.GDchestObjects3= [];
gdjs.level_321Code.GDchestObjects4= [];
gdjs.level_321Code.GDchestObjects5= [];
gdjs.level_321Code.GDfire_9595keybindObjects1= [];
gdjs.level_321Code.GDfire_9595keybindObjects2= [];
gdjs.level_321Code.GDfire_9595keybindObjects3= [];
gdjs.level_321Code.GDfire_9595keybindObjects4= [];
gdjs.level_321Code.GDfire_9595keybindObjects5= [];
gdjs.level_321Code.GDfireButtonObjects1= [];
gdjs.level_321Code.GDfireButtonObjects2= [];
gdjs.level_321Code.GDfireButtonObjects3= [];
gdjs.level_321Code.GDfireButtonObjects4= [];
gdjs.level_321Code.GDfireButtonObjects5= [];
gdjs.level_321Code.GDmineshaftObjects1= [];
gdjs.level_321Code.GDmineshaftObjects2= [];
gdjs.level_321Code.GDmineshaftObjects3= [];
gdjs.level_321Code.GDmineshaftObjects4= [];
gdjs.level_321Code.GDmineshaftObjects5= [];
gdjs.level_321Code.GDNewSpriteObjects1= [];
gdjs.level_321Code.GDNewSpriteObjects2= [];
gdjs.level_321Code.GDNewSpriteObjects3= [];
gdjs.level_321Code.GDNewSpriteObjects4= [];
gdjs.level_321Code.GDNewSpriteObjects5= [];
gdjs.level_321Code.GDbig_9595rock_95951Objects1= [];
gdjs.level_321Code.GDbig_9595rock_95951Objects2= [];
gdjs.level_321Code.GDbig_9595rock_95951Objects3= [];
gdjs.level_321Code.GDbig_9595rock_95951Objects4= [];
gdjs.level_321Code.GDbig_9595rock_95951Objects5= [];
gdjs.level_321Code.GDbig_9595rock_95952Objects1= [];
gdjs.level_321Code.GDbig_9595rock_95952Objects2= [];
gdjs.level_321Code.GDbig_9595rock_95952Objects3= [];
gdjs.level_321Code.GDbig_9595rock_95952Objects4= [];
gdjs.level_321Code.GDbig_9595rock_95952Objects5= [];
gdjs.level_321Code.GDbig_9595rock_95953Objects1= [];
gdjs.level_321Code.GDbig_9595rock_95953Objects2= [];
gdjs.level_321Code.GDbig_9595rock_95953Objects3= [];
gdjs.level_321Code.GDbig_9595rock_95953Objects4= [];
gdjs.level_321Code.GDbig_9595rock_95953Objects5= [];
gdjs.level_321Code.GDsmall_9595rock_95951Objects1= [];
gdjs.level_321Code.GDsmall_9595rock_95951Objects2= [];
gdjs.level_321Code.GDsmall_9595rock_95951Objects3= [];
gdjs.level_321Code.GDsmall_9595rock_95951Objects4= [];
gdjs.level_321Code.GDsmall_9595rock_95951Objects5= [];
gdjs.level_321Code.GDNewSprite2Objects1= [];
gdjs.level_321Code.GDNewSprite2Objects2= [];
gdjs.level_321Code.GDNewSprite2Objects3= [];
gdjs.level_321Code.GDNewSprite2Objects4= [];
gdjs.level_321Code.GDNewSprite2Objects5= [];
gdjs.level_321Code.GDrocksObjects1= [];
gdjs.level_321Code.GDrocksObjects2= [];
gdjs.level_321Code.GDrocksObjects3= [];
gdjs.level_321Code.GDrocksObjects4= [];
gdjs.level_321Code.GDrocksObjects5= [];
gdjs.level_321Code.GDmazeObjects1= [];
gdjs.level_321Code.GDmazeObjects2= [];
gdjs.level_321Code.GDmazeObjects3= [];
gdjs.level_321Code.GDmazeObjects4= [];
gdjs.level_321Code.GDmazeObjects5= [];
gdjs.level_321Code.GD_95950003_95956Objects1= [];
gdjs.level_321Code.GD_95950003_95956Objects2= [];
gdjs.level_321Code.GD_95950003_95956Objects3= [];
gdjs.level_321Code.GD_95950003_95956Objects4= [];
gdjs.level_321Code.GD_95950003_95956Objects5= [];
gdjs.level_321Code.GD_95950008_95953Objects1= [];
gdjs.level_321Code.GD_95950008_95953Objects2= [];
gdjs.level_321Code.GD_95950008_95953Objects3= [];
gdjs.level_321Code.GD_95950008_95953Objects4= [];
gdjs.level_321Code.GD_95950008_95953Objects5= [];
gdjs.level_321Code.GD_95950010_95951Objects1= [];
gdjs.level_321Code.GD_95950010_95951Objects2= [];
gdjs.level_321Code.GD_95950010_95951Objects3= [];
gdjs.level_321Code.GD_95950010_95951Objects4= [];
gdjs.level_321Code.GD_95950010_95951Objects5= [];
gdjs.level_321Code.GDNewTiledSpriteObjects1= [];
gdjs.level_321Code.GDNewTiledSpriteObjects2= [];
gdjs.level_321Code.GDNewTiledSpriteObjects3= [];
gdjs.level_321Code.GDNewTiledSpriteObjects4= [];
gdjs.level_321Code.GDNewTiledSpriteObjects5= [];
gdjs.level_321Code.GDmilkObjects1= [];
gdjs.level_321Code.GDmilkObjects2= [];
gdjs.level_321Code.GDmilkObjects3= [];
gdjs.level_321Code.GDmilkObjects4= [];
gdjs.level_321Code.GDmilkObjects5= [];
gdjs.level_321Code.GDplayerObjects1= [];
gdjs.level_321Code.GDplayerObjects2= [];
gdjs.level_321Code.GDplayerObjects3= [];
gdjs.level_321Code.GDplayerObjects4= [];
gdjs.level_321Code.GDplayerObjects5= [];
gdjs.level_321Code.GDghostObjects1= [];
gdjs.level_321Code.GDghostObjects2= [];
gdjs.level_321Code.GDghostObjects3= [];
gdjs.level_321Code.GDghostObjects4= [];
gdjs.level_321Code.GDghostObjects5= [];


gdjs.level_321Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "MobileControls");
}}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.level_321Code.GDghostObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.level_321Code.GDghostObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.asyncCallback17010836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.level_321Code.asyncCallback17010836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback16862796 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects4);

{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects4[i].getBehavior("Animation").setAnimationName("Idle");
}
}
{ //Subevents
gdjs.level_321Code.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDplayerObjects3) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.level_321Code.asyncCallback16862796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback13275916 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects3[i].getBehavior("Animation").setAnimationName("Fall");
}
}
{ //Subevents
gdjs.level_321Code.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.level_321Code.asyncCallback13275916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.level_321Code.GDplayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDplayerObjects2[i].getBehavior("HorizontalDash").IsDashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDplayerObjects2[k] = gdjs.level_321Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("Dash");
}
}
{ //Subevents
gdjs.level_321Code.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.asyncCallback9500852 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDplayerObjects1) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.level_321Code.asyncCallback9500852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.level_321Code.GDghostObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.level_321Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDghostObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.level_321Code.GDghostObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.level_321Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDghostObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.level_321Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.level_321Code.GDJumpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDJumpObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDJumpObjects2[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDJumpObjects2[k] = gdjs.level_321Code.GDJumpObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDJumpObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slide"), gdjs.level_321Code.GDSlideObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDSlideObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDSlideObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDSlideObjects1[k] = gdjs.level_321Code.GDSlideObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDSlideObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16969996);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects1[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects1[i].getBehavior("Animation").setAnimationName("Dash");
}
}
{ //Subevents
gdjs.level_321Code.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("mstrVolSlider"), gdjs.level_321Code.GDmstrVolSliderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDmstrVolSliderObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDmstrVolSliderObjects3[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDmstrVolSliderObjects3[k] = gdjs.level_321Code.GDmstrVolSliderObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDmstrVolSliderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDmstrVolSliderObjects3 */
gdjs.copyArray(runtimeScene.getObjects("mstrVolValue"), gdjs.level_321Code.GDmstrVolValueObjects3);
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, (( gdjs.level_321Code.GDmstrVolSliderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmstrVolSliderObjects3[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}{for(var i = 0, len = gdjs.level_321Code.GDmstrVolValueObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDmstrVolValueObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.level_321Code.GDmstrVolSliderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmstrVolSliderObjects3[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sndEffctsVolSlider"), gdjs.level_321Code.GDsndEffctsVolSliderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDsndEffctsVolSliderObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDsndEffctsVolSliderObjects3[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDsndEffctsVolSliderObjects3[k] = gdjs.level_321Code.GDsndEffctsVolSliderObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDsndEffctsVolSliderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDsndEffctsVolSliderObjects3 */
{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 1, (( gdjs.level_321Code.GDsndEffctsVolSliderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDsndEffctsVolSliderObjects3[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("bgMusicVolSlider"), gdjs.level_321Code.GDbgMusicVolSliderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDbgMusicVolSliderObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDbgMusicVolSliderObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDbgMusicVolSliderObjects2[k] = gdjs.level_321Code.GDbgMusicVolSliderObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDbgMusicVolSliderObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDbgMusicVolSliderObjects2 */
{gdjs.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 69, (( gdjs.level_321Code.GDbgMusicVolSliderObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDbgMusicVolSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


};gdjs.level_321Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("settings_icon"), gdjs.level_321Code.GDsettings_9595iconObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDsettings_9595iconObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDsettings_9595iconObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDsettings_9595iconObjects2[k] = gdjs.level_321Code.GDsettings_9595iconObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDsettings_9595iconObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Settings Window");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.level_321Code.GDexitButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDexitButtonObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDexitButtonObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDexitButtonObjects1[k] = gdjs.level_321Code.GDexitButtonObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDexitButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Settings Window");
}}

}


};gdjs.level_321Code.eventsList9 = function(runtimeScene) {

{


gdjs.level_321Code.eventsList7(runtimeScene);
}


{


gdjs.level_321Code.eventsList8(runtimeScene);
}


};gdjs.level_321Code.asyncCallback8209172 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects4);

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "..\\..\\..\\Downloads\\fire going 1.mp3", 1, true, 100, 1);
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects4[i].returnVariable(gdjs.level_321Code.GDFlameObjects4[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects4.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects4[i].stopEmission();
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDExplosion1Objects3) asyncObjectsList.addObject("Explosion1", obj);
for (const obj of gdjs.level_321Code.GDFlameObjects3) asyncObjectsList.addObject("Flame", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.level_321Code.asyncCallback8209172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback21419908 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects4);

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "..\\..\\..\\Downloads\\fire going 1.mp3", 1, true, 100, 1);
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects4[i].returnVariable(gdjs.level_321Code.GDFlameObjects4[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects4.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects4[i].stopEmission();
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDExplosion1Objects3) asyncObjectsList.addObject("Explosion1", obj);
for (const obj of gdjs.level_321Code.GDFlameObjects3) asyncObjectsList.addObject("Flame", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.level_321Code.asyncCallback21419908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9338492);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects3.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects3[i].startEmission();
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "flame start sound effect 2.mp3", 1, false, 100, 1);
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].startEmission();
}
}
{ //Subevents
gdjs.level_321Code.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("fireButton"), gdjs.level_321Code.GDfireButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDfireButtonObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDfireButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDfireButtonObjects3[k] = gdjs.level_321Code.GDfireButtonObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDfireButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20738180);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects3.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects3[i].startEmission();
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "flame start sound effect 2.mp3", 1, false, 100, 1);
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].startEmission();
}
}
{ //Subevents
gdjs.level_321Code.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects3);
gdjs.copyArray(runtimeScene.getObjects("mousePos"), gdjs.level_321Code.GDmousePosObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("zombieHealth"), gdjs.level_321Code.GDzombieHealthObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDlineObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlineObjects3[i].rotateTowardPosition((( gdjs.level_321Code.GDmousePosObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmousePosObjects3[0].getPointX("")), (( gdjs.level_321Code.GDmousePosObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmousePosObjects3[0].getPointY("")), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlineObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlineObjects3[i].getBehavior("Resizable").setWidth(gdjs.evtTools.common.distanceBetweenPositions((( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointX("Attack")), (( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointY("Attack")), (( gdjs.level_321Code.GDmousePosObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmousePosObjects3[0].getPointX("")), (( gdjs.level_321Code.GDmousePosObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDmousePosObjects3[0].getPointY(""))) / 2.5);
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].rotateTowardPosition((( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getPointX("End")), (( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getPointY("End")), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].setEmitterForceMax(gdjs.evtTools.common.distanceBetweenPositions((( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getCenterXInScene()), (( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getCenterYInScene()), (( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getPointX("End")), (( gdjs.level_321Code.GDlineObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlineObjects3[0].getPointY("End"))) * 3.53);
}
}{for(var i = 0, len = gdjs.level_321Code.GDzombieHealthObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDzombieHealthObjects3[i].setPosition((( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointX("")) + 5,(( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointY("")) - 20);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("fireButton"), gdjs.level_321Code.GDfireButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDfireButtonObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDfireButtonObjects3[i].getBehavior("MultitouchButton").IsReleased((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDfireButtonObjects3[k] = gdjs.level_321Code.GDfireButtonObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDfireButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20103588);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects3.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects3[i].startEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].stopEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects3[i].returnVariable(gdjs.level_321Code.GDFlameObjects3[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects3.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects3[i].stopEmission();
}
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18582100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects2[i].startEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects2[i].stopEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects2[i].returnVariable(gdjs.level_321Code.GDFlameObjects2[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects2[i].stopEmission();
}
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}}

}


};gdjs.level_321Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.level_321Code.GDlaternObjects2, gdjs.level_321Code.GDlaternObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects3[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects3[k] = gdjs.level_321Code.GDlaternObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects3[i].getBehavior("Animation").setAnimationName("On");
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects3[i].getBehavior("Effect").enableEffect("Effect", true);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects3[i].getBehavior("Effect").enableEffect("Effect2", true);
}
}}

}


{

/* Reuse gdjs.level_321Code.GDlaternObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects2[k] = gdjs.level_321Code.GDlaternObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].getBehavior("Animation").setAnimationName("Off");
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].getBehavior("Effect").enableEffect("Effect", false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].getBehavior("Effect").enableEffect("Effect2", false);
}
}}

}


};gdjs.level_321Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "laternFuel2Timer", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects2[k] = gdjs.level_321Code.GDlaternObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) < 100;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].returnVariable(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(2)).setBoolean(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 100;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].returnVariable(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(2)).setBoolean(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].returnVariable(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects2[k] = gdjs.level_321Code.GDlaternObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) != 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(18456356);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects2[i].returnVariable(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(1)).toggle();
}
}
{ //Subevents
gdjs.level_321Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "laternFuelTimer", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects2[k] = gdjs.level_321Code.GDlaternObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects2[i].getVariables().getFromIndex(2), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects2[k] = gdjs.level_321Code.GDlaternObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects2.length = k;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).sub(10);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects1[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects1[i].getVariables().getFromIndex(2), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects1[k] = gdjs.level_321Code.GDlaternObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "laternRefuelTimer", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).add(10);
}}

}


};gdjs.level_321Code.eventsList15 = function(runtimeScene) {

{


gdjs.level_321Code.eventsList12(runtimeScene);
}


{


gdjs.level_321Code.eventsList14(runtimeScene);
}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDcheckpointObjects1Objects = Hashtable.newFrom({"checkpoint": gdjs.level_321Code.GDcheckpointObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.asyncCallback23789652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("checkpoint"), gdjs.level_321Code.GDcheckpointObjects2);

{for(var i = 0, len = gdjs.level_321Code.GDcheckpointObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDcheckpointObjects2[i].getBehavior("Animation").setAnimationName("On");
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDcheckpointObjects1) asyncObjectsList.addObject("checkpoint", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23789652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("checkpoint"), gdjs.level_321Code.GDcheckpointObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDcheckpointObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDcheckpointObjects1 */
/* Reuse gdjs.level_321Code.GDplayerObjects1 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, (( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("")), "checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.level_321Code.GDcheckpointObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDcheckpointObjects1[i].getBehavior("Animation").setAnimationName("Claim");
}
}
{ //Subevents
gdjs.level_321Code.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDkillLineObjects2Objects = Hashtable.newFrom({"killLine": gdjs.level_321Code.GDkillLineObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDtransistionObjects1Objects = Hashtable.newFrom({"transistion": gdjs.level_321Code.GDtransistionObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.asyncCallback23757204 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("fallingPlatform"), gdjs.level_321Code.GDfallingPlatformObjects4);

{for(var i = 0, len = gdjs.level_321Code.GDfallingPlatformObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDfallingPlatformObjects4[i].setY(gdjs.level_321Code.GDfallingPlatformObjects4[i].getY() - (2500));
}
}{for(var i = 0, len = gdjs.level_321Code.GDfallingPlatformObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDfallingPlatformObjects4[i].returnVariable(gdjs.level_321Code.GDfallingPlatformObjects4[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDfallingPlatformObjects3) asyncObjectsList.addObject("fallingPlatform", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.level_321Code.asyncCallback23757204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList19 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(runtimeScene.getObjects("fallingPlatform"), gdjs.level_321Code.GDfallingPlatformObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDfallingPlatformObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDfallingPlatformObjects3[i].getVariableBoolean(gdjs.level_321Code.GDfallingPlatformObjects3[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDfallingPlatformObjects3[k] = gdjs.level_321Code.GDfallingPlatformObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDfallingPlatformObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.level_321Code.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.level_321Code.asyncCallback23735068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("transistion"), gdjs.level_321Code.GDtransistionObjects3);

{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects3[i].hide();
}
}
{ //Subevents
gdjs.level_321Code.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDtransistionObjects2) asyncObjectsList.addObject("transistion", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.level_321Code.asyncCallback23735068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback23771028 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("transistion"), gdjs.level_321Code.GDtransistionObjects2);

{gdjs.evtsExt__Checkpoints__LoadCheckpoint.func(runtimeScene, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, "checkpoint", false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects2[i].getBehavior("Tween").addObjectScaleTween3("scale_down_transition_tween", 0.001, "easeOutSine", 0.3, false, true);
}
}
{ //Subevents
gdjs.level_321Code.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDplayerObjects1) asyncObjectsList.addObject("player", obj);
for (const obj of gdjs.level_321Code.GDtransistionObjects1) asyncObjectsList.addObject("transistion", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.35), (runtimeScene) => (gdjs.level_321Code.asyncCallback23771028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("killLine"), gdjs.level_321Code.GDkillLineObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDkillLineObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23773356);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("Health").SetHealth(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDplayerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDplayerObjects1[k] = gdjs.level_321Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("deathCountText"), gdjs.level_321Code.GDdeathCountTextObjects1);
/* Reuse gdjs.level_321Code.GDplayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("transistion"), gdjs.level_321Code.GDtransistionObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects1[i].getBehavior("Health").SetHealth(10, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects1[i].hide(false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.level_321Code.GDdeathCountTextObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDdeathCountTextObjects1[i].getBehavior("Text").setText("Deaths: " + runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDtransistionObjects1Objects, "Transition", gdjs.evtTools.window.getWindowInnerWidth() / 2, gdjs.evtTools.window.getWindowInnerHeight() / 2, "UI");
}{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects1[i].getBehavior("Tween").addObjectScaleTween3("scale_transition_tween", 100, "easeInSine", 0.3, false, true);
}
}
{ //Subevents
gdjs.level_321Code.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects = Hashtable.newFrom({"line": gdjs.level_321Code.GDlineObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects = Hashtable.newFrom({"Zombie": gdjs.level_321Code.GDZombieObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects = Hashtable.newFrom({"Zombie": gdjs.level_321Code.GDZombieObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects = Hashtable.newFrom({"Zombie": gdjs.level_321Code.GDZombieObjects3});
gdjs.level_321Code.asyncCallback23753844 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("damage"), gdjs.level_321Code.GDdamageObjects5);

{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects5.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects5[i].hide();
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDdamageObjects4) asyncObjectsList.addObject("damage", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23753844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback23794172 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects4);

gdjs.copyArray(runtimeScene.getObjects("damage"), gdjs.level_321Code.GDdamageObjects4);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects4);

{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects4[i].getBehavior("Animation").setAnimationName("Walk");
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects4[i].getBehavior("Health").Hit(1.5, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.level_321Code.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDZombieObjects3) asyncObjectsList.addObject("Zombie", obj);
for (const obj of gdjs.level_321Code.GDplayerObjects3) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23794172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.asyncCallback23798164 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);

gdjs.copyArray(runtimeScene.getObjects("zombieHealth"), gdjs.level_321Code.GDzombieHealthObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDzombieHealthObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDzombieHealthObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].deleteFromScene(runtimeScene);
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDZombieObjects2) asyncObjectsList.addObject("Zombie", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.level_321Code.asyncCallback23798164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDFlameObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDFlameObjects3[i].getVariableBoolean(gdjs.level_321Code.GDFlameObjects3[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDFlameObjects3[k] = gdjs.level_321Code.GDFlameObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDFlameObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDZombieObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects, 500, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23735324);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDZombieObjects3 */
gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].returnVariable(gdjs.level_321Code.GDZombieObjects3[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects3[i].getBehavior("Pathfinding").setAcceleration(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDZombieObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDZombieObjects3[i].getVariableBoolean(gdjs.level_321Code.GDZombieObjects3[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDZombieObjects3[k] = gdjs.level_321Code.GDZombieObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDZombieObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDZombieObjects3 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].activateBehavior("Pathfinding", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDZombieObjects3Objects, 20, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "zombieAttack", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDZombieObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].getBehavior("Animation").setAnimationName("Attack");
}
}
{ //Subevents
gdjs.level_321Code.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, (( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointX("")), (( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointY("")), 180, 300, runtimeScene.getScene().getVariables().getFromIndex(5), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= (( gdjs.level_321Code.GDlaywerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects3[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, (( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointX("")), (( gdjs.level_321Code.GDZombieObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects3[0].getPointY("")), -(90), 300, runtimeScene.getScene().getVariables().getFromIndex(4), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) <= (( gdjs.level_321Code.GDlaywerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects3[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDZombieObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDZombieObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDZombieObjects2[k] = gdjs.level_321Code.GDZombieObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDZombieObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDZombieObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects2[i].getBehavior("Animation").setAnimationName("Die");
}
}
{ //Subevents
gdjs.level_321Code.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects = Hashtable.newFrom({"line": gdjs.level_321Code.GDlineObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.level_321Code.GDSpiderObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.level_321Code.GDSpiderObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.level_321Code.GDSpiderObjects3});
gdjs.level_321Code.asyncCallback23754676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects5);

{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects5.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects5[i].clearForces();
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects5.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects5[i].getBehavior("Animation").setAnimationName("Fall");
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDSpiderObjects4) asyncObjectsList.addObject("Spider", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.level_321Code.asyncCallback23754676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback23754404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.level_321Code.GDplayerObjects4);

{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects4[i].addForceTowardPosition((( gdjs.level_321Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects4[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects4.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects4[0].getPointY("")), 1000, 1);
}
}
{ //Subevents
gdjs.level_321Code.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDSpiderObjects3) asyncObjectsList.addObject("Spider", obj);
for (const obj of gdjs.level_321Code.GDplayerObjects3) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.level_321Code.asyncCallback23754404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.level_321Code.GDSpiderObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.asyncCallback23765340 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("damage"), gdjs.level_321Code.GDdamageObjects4);

{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects4.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects4[i].hide();
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDdamageObjects3) asyncObjectsList.addObject("damage", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23765340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects = Hashtable.newFrom({"line": gdjs.level_321Code.GDlineObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.level_321Code.GDSpiderObjects3});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDFlameObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDFlameObjects3[i].getVariableBoolean(gdjs.level_321Code.GDFlameObjects3[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDFlameObjects3[k] = gdjs.level_321Code.GDFlameObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDFlameObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects3[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects3[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects3[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects3[k] = gdjs.level_321Code.GDlaternObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects, 800, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
/* Reuse gdjs.level_321Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects3[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Pathfinding").setSpeed(175);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects, 150, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects3[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects3[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects3[k] = gdjs.level_321Code.GDlaternObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("PlatformerObject").setGravity(1100);
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("PlatformerObject").setJumpSpeed(1000);
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Animation").setAnimationName("Jump Prepare");
}
}
{ //Subevents
gdjs.level_321Code.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
gdjs.copyArray(runtimeScene.getObjects("damage"), gdjs.level_321Code.GDdamageObjects3);
/* Reuse gdjs.level_321Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects3[i].getBehavior("Health").Hit(0.75, true, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.level_321Code.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDSpiderObjects3[k] = gdjs.level_321Code.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDSpiderObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
gdjs.copyArray(runtimeScene.getObjects("spiderHealth"), gdjs.level_321Code.GDspiderHealthObjects3);
{for(var i = 0, len = gdjs.level_321Code.GDspiderHealthObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDspiderHealthObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects3Objects, (( gdjs.level_321Code.GDSpiderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects3[0].getCenterXInScene()), (( gdjs.level_321Code.GDSpiderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects3[0].getCenterYInScene()), -(90), 500, runtimeScene.getScene().getVariables().getFromIndex(6), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) <= (( gdjs.level_321Code.GDSpiderObjects3.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects3[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects3Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDSpiderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDFlameObjects3.length;i<l;++i) {
    if ( gdjs.level_321Code.GDFlameObjects3[i].getVariableBoolean(gdjs.level_321Code.GDFlameObjects3[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDFlameObjects3[k] = gdjs.level_321Code.GDFlameObjects3[i];
        ++k;
    }
}
gdjs.level_321Code.GDFlameObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects3[i].getBehavior("Health").Hit(0.75, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, (( gdjs.level_321Code.GDSpiderObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects2[0].getCenterXInScene()), (( gdjs.level_321Code.GDSpiderObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects2[0].getCenterYInScene()), 180, 500, runtimeScene.getScene().getVariables().getFromIndex(7), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) >= (( gdjs.level_321Code.GDSpiderObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects2[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects2Objects = Hashtable.newFrom({"line": gdjs.level_321Code.GDlineObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects = Hashtable.newFrom({"laywer": gdjs.level_321Code.GDlaywerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects = Hashtable.newFrom({"laywer": gdjs.level_321Code.GDlaywerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects = Hashtable.newFrom({"laywer": gdjs.level_321Code.GDlaywerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects = Hashtable.newFrom({"laywer": gdjs.level_321Code.GDlaywerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbreifcaseObjects2Objects = Hashtable.newFrom({"breifcase": gdjs.level_321Code.GDbreifcaseObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.asyncCallback23757796 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects3);

{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects3[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects3[i].returnVariable(gdjs.level_321Code.GDlaywerObjects3[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDlaywerObjects2) asyncObjectsList.addObject("laywer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.75), (runtimeScene) => (gdjs.level_321Code.asyncCallback23757796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbreifcaseObjects2Objects = Hashtable.newFrom({"breifcase": gdjs.level_321Code.GDbreifcaseObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.asyncCallback23729612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("damage"), gdjs.level_321Code.GDdamageObjects3);

{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects3[i].hide();
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDdamageObjects2) asyncObjectsList.addObject("damage", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23729612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects2);
gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects2);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlineObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDFlameObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDFlameObjects2[i].getVariableBoolean(gdjs.level_321Code.GDFlameObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDFlameObjects2[k] = gdjs.level_321Code.GDFlameObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDFlameObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Health").Hit(1, false, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects, 750, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaywerObjects2.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaywerObjects2[i].getVariableBoolean(gdjs.level_321Code.GDlaywerObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaywerObjects2[k] = gdjs.level_321Code.GDlaywerObjects2[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaywerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects, 500, true);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects2 */
/* Reuse gdjs.level_321Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.level_321Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects2[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Pathfinding").setAcceleration(400);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Animation").setAnimationName("Move");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaywerObjects2Objects, 500, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "laywerAttackLoop", 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23759372);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects2 */
/* Reuse gdjs.level_321Code.GDplayerObjects2 */
gdjs.level_321Code.GDbreifcaseObjects2.length = 0;

{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].returnVariable(gdjs.level_321Code.GDlaywerObjects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Pathfinding").setAcceleration(0);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Animation").setAnimationName("Throw");
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("FireBullet").FireTowardObject((gdjs.level_321Code.GDlaywerObjects2[i].getPointX("throw")), (gdjs.level_321Code.GDlaywerObjects2[i].getPointY("throw")), gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbreifcaseObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, 350, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDbreifcaseObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDbreifcaseObjects2[i].getBehavior("Scale").setScale(2);
}
}
{ //Subevents
gdjs.level_321Code.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("breifcase"), gdjs.level_321Code.GDbreifcaseObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbreifcaseObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDbreifcaseObjects2 */
gdjs.copyArray(runtimeScene.getObjects("damage"), gdjs.level_321Code.GDdamageObjects2);
/* Reuse gdjs.level_321Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDbreifcaseObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDbreifcaseObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.level_321Code.GDbreifcaseObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDbreifcaseObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.level_321Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDplayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.level_321Code.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getCenterXInScene()), (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getCenterYInScene()), -(90), 300, runtimeScene.getScene().getVariables().getFromIndex(2), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.raycastObject(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getCenterXInScene()), (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getCenterYInScene()), 180, 300, runtimeScene.getScene().getVariables().getFromIndex(3), runtimeScene.getScene().getVariables().getFromIndex(8), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) <= (( gdjs.level_321Code.GDlaywerObjects2.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects2[0].getPointX(""));
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaywerObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaywerObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaywerObjects1[k] = gdjs.level_321Code.GDlaywerObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaywerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaywerObjects1 */
{for(var i = 0, len = gdjs.level_321Code.GDlaywerObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.level_321Code.eventsList34 = function(runtimeScene) {

{


gdjs.level_321Code.eventsList26(runtimeScene);
}


{


gdjs.level_321Code.eventsList30(runtimeScene);
}


{


gdjs.level_321Code.eventsList33(runtimeScene);
}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDfallingPlatformObjects2Objects = Hashtable.newFrom({"fallingPlatform": gdjs.level_321Code.GDfallingPlatformObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects2});
gdjs.level_321Code.asyncCallback23791924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("fallingPlatform"), gdjs.level_321Code.GDfallingPlatformObjects3);

{for(var i = 0, len = gdjs.level_321Code.GDfallingPlatformObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDfallingPlatformObjects3[i].getBehavior("Tween").addObjectPositionTween2("fallingPlatformDown", (gdjs.level_321Code.GDfallingPlatformObjects3[i].getPointX("")), (gdjs.level_321Code.GDfallingPlatformObjects3[i].getPointY("")) + 2500, "easeInCirc", 1.75, false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDfallingPlatformObjects3.length ;i < len;++i) {
    gdjs.level_321Code.GDfallingPlatformObjects3[i].returnVariable(gdjs.level_321Code.GDfallingPlatformObjects3[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
for (const obj of gdjs.level_321Code.GDfallingPlatformObjects2) asyncObjectsList.addObject("fallingPlatform", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.0025), (runtimeScene) => (gdjs.level_321Code.asyncCallback23791924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("fallingPlatform"), gdjs.level_321Code.GDfallingPlatformObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDfallingPlatformObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23791764);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.level_321Code.eventsList35(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDchestObjects1Objects = Hashtable.newFrom({"chest": gdjs.level_321Code.GDchestObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDtransistionObjects2Objects = Hashtable.newFrom({"transistion": gdjs.level_321Code.GDtransistionObjects2});
gdjs.level_321Code.asyncCallback23794860 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "endScreen", false);
}gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.level_321Code.asyncCallback23794860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.asyncCallback23772652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transistion"), gdjs.level_321Code.GDtransistionObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects2[i].hide(false);
}
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDtransistionObjects2Objects, "Transition", gdjs.evtTools.window.getWindowInnerWidth() / 2, gdjs.evtTools.window.getWindowInnerHeight() / 2, "UI");
}{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects2[i].getBehavior("Tween").addObjectScaleTween3("scale_transition_tween", 100, "easeInSine", 0.75, false, true);
}
}
{ //Subevents
gdjs.level_321Code.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.level_321Code.asyncCallback23772652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.level_321Code.eventsList39 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("chest"), gdjs.level_321Code.GDchestObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDchestObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, 25, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Tab");
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDchestObjects1 */
gdjs.copyArray(runtimeScene.getObjects("milk"), gdjs.level_321Code.GDmilkObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDchestObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDchestObjects1[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = gdjs.level_321Code.GDmilkObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDmilkObjects1[i].getBehavior("Tween").addObjectPositionTween2("tweenMilkReveal", (gdjs.level_321Code.GDmilkObjects1[i].getPointX("")), (gdjs.level_321Code.GDmilkObjects1[i].getPointY("")) - 8, "linear", 0.75, false);
}
}
{ //Subevents
gdjs.level_321Code.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.level_321Code.GDplayerObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaternObjects1Objects = Hashtable.newFrom({"latern": gdjs.level_321Code.GDlaternObjects1});
gdjs.level_321Code.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects1);
gdjs.copyArray(runtimeScene.getObjects("damage"), gdjs.level_321Code.GDdamageObjects1);
gdjs.copyArray(runtimeScene.getObjects("lanternFuelBar"), gdjs.level_321Code.GDlanternFuelBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects1);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects1);
gdjs.copyArray(runtimeScene.getObjects("mousePos"), gdjs.level_321Code.GDmousePosObjects1);
gdjs.copyArray(runtimeScene.getObjects("transistion"), gdjs.level_321Code.GDtransistionObjects1);
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}{gdjs.deviceVibration.startVibration(999999);
}{gdjs.evtTools.window.setAdaptGameResolutionAtRuntime(runtimeScene, true);
}{for(var i = 0, len = gdjs.level_321Code.GDlineObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlineObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects1[i].stopEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects1[i].stopEmission();
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects1[i].getBehavior("Effect").enableEffect("Effect", false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects1[i].getBehavior("Effect").enableEffect("Effect2", false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDtransistionObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDtransistionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.level_321Code.GDmousePosObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDmousePosObjects1[i].hide();
}
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "..\\..\\..\\Downloads\\flame start sound effect 2.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "..\\..\\..\\Downloads\\fire going 1.mp3");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "..\\..\\..\\Downloads\\PumkinSong.wav", 69, true, 50, 1);
}{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects1[i].hide();
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}{for(var i = 0, len = gdjs.level_321Code.GDdamageObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDdamageObjects1[i].setLayer("UI");
}
}{for(var i = 0, len = gdjs.level_321Code.GDlanternFuelBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlanternFuelBarObjects1[i].SetMaxValue(100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(100);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.35, "", 0);
}{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects1[i].getBehavior("Animation").setAnimationName("Off");
}
}
{ //Subevents
gdjs.level_321Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__RepeatXTimes.func(runtimeScene, "vibrate", 999.999, -(1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(999999);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("lava"), gdjs.level_321Code.GDlavaObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDlavaObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlavaObjects1[i].setXOffset(gdjs.level_321Code.GDlavaObjects1[i].getXOffset() + (30 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(19946500);
}
if (isConditionTrue_0) {
{gdjs.evtTools.advancedWindow.maximize(true, runtimeScene);
}{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Explosion1"), gdjs.level_321Code.GDExplosion1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Flame"), gdjs.level_321Code.GDFlameObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects1);
gdjs.copyArray(runtimeScene.getObjects("killLine"), gdjs.level_321Code.GDkillLineObjects1);
gdjs.copyArray(runtimeScene.getObjects("lanternFuelBar"), gdjs.level_321Code.GDlanternFuelBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("line"), gdjs.level_321Code.GDlineObjects1);
gdjs.copyArray(runtimeScene.getObjects("mousePos"), gdjs.level_321Code.GDmousePosObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDmousePosObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDmousePosObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - 10,gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - 10);
}
}{for(var i = 0, len = gdjs.level_321Code.GDlineObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlineObjects1[i].setPosition((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("Attack")),(( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("Attack")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDFlameObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDFlameObjects1[i].setPosition((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("Attack")),(( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("Attack")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDExplosion1Objects1.length ;i < len;++i) {
    gdjs.level_321Code.GDExplosion1Objects1[i].setPosition((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("Attack")),(( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("Attack")));
}
}{for(var i = 0, len = gdjs.level_321Code.GDlanternFuelBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlanternFuelBarObjects1[i].SetValue(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDZombieObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDZombieObjects1[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.level_321Code.GDSpiderObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDSpiderObjects1[i].getBehavior("Pathfinding").setSpeed(25);
}
}{gdjs.evtTools.camera.clampCamera(runtimeScene, 0, 0, (( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("")) + 5000, (( gdjs.level_321Code.GDkillLineObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDkillLineObjects1[0].getPointY("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects1[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects1[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects1[k] = gdjs.level_321Code.GDlaternObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects1.length = k;
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.level_321Code.GDghostObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDghostObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, 65, true);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDghostObjects1 */
/* Reuse gdjs.level_321Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.level_321Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDghostObjects1[i].getBehavior("Pathfinding").setSpeed(160);
}
}{for(var i = 0, len = gdjs.level_321Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("")), (( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.level_321Code.GDghostObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDghostObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, 65, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDghostObjects1 */
{for(var i = 0, len = gdjs.level_321Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDghostObjects1[i].getBehavior("Pathfinding").setSpeed(0);
}
}}

}


{


gdjs.level_321Code.eventsList6(runtimeScene);
}


{


gdjs.level_321Code.eventsList9(runtimeScene);
}


{


gdjs.level_321Code.eventsList15(runtimeScene);
}


{


gdjs.level_321Code.eventsList17(runtimeScene);
}


{


gdjs.level_321Code.eventsList22(runtimeScene);
}


{


gdjs.level_321Code.eventsList34(runtimeScene);
}


{


gdjs.level_321Code.eventsList36(runtimeScene);
}


{


gdjs.level_321Code.eventsList39(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDplayerObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDlaternObjects1Objects, 20, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23778476);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects1 */
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects1[i].returnVariable(gdjs.level_321Code.GDlaternObjects1[i].getVariables().getFromIndex(0)).toggle();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("latern"), gdjs.level_321Code.GDlaternObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_321Code.GDlaternObjects1.length;i<l;++i) {
    if ( gdjs.level_321Code.GDlaternObjects1[i].getVariableBoolean(gdjs.level_321Code.GDlaternObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.level_321Code.GDlaternObjects1[k] = gdjs.level_321Code.GDlaternObjects1[i];
        ++k;
    }
}
gdjs.level_321Code.GDlaternObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDlaternObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDlaternObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaternObjects1[i].setPosition((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointX("equipment")),(( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getPointY("equipment")));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.level_321Code.GDSpiderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie"), gdjs.level_321Code.GDZombieObjects1);
gdjs.copyArray(runtimeScene.getObjects("heartBar"), gdjs.level_321Code.GDheartBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("laywer"), gdjs.level_321Code.GDlaywerObjects1);
gdjs.copyArray(runtimeScene.getObjects("laywerHealthBar"), gdjs.level_321Code.GDlaywerHealthBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.level_321Code.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spiderHealth"), gdjs.level_321Code.GDspiderHealthObjects1);
gdjs.copyArray(runtimeScene.getObjects("zombieHealth"), gdjs.level_321Code.GDzombieHealthObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDheartBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDheartBarObjects1[i].SetMaxValue((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDheartBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDheartBarObjects1[i].SetValue((( gdjs.level_321Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDplayerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDzombieHealthObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDzombieHealthObjects1[i].SetMaxValue((( gdjs.level_321Code.GDZombieObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDzombieHealthObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDzombieHealthObjects1[i].SetValue((( gdjs.level_321Code.GDZombieObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDZombieObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerHealthBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerHealthBarObjects1[i].SetMaxValue((( gdjs.level_321Code.GDlaywerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerHealthBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerHealthBarObjects1[i].SetValue((( gdjs.level_321Code.GDlaywerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDlaywerHealthBarObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDlaywerHealthBarObjects1[i].setPosition((( gdjs.level_321Code.GDlaywerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects1[0].getPointX("")),(( gdjs.level_321Code.GDlaywerObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDlaywerObjects1[0].getPointY("")) - 25);
}
}{for(var i = 0, len = gdjs.level_321Code.GDspiderHealthObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDspiderHealthObjects1[i].SetMaxValue((( gdjs.level_321Code.GDSpiderObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDspiderHealthObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDspiderHealthObjects1[i].SetValue((( gdjs.level_321Code.GDSpiderObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.level_321Code.GDspiderHealthObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDspiderHealthObjects1[i].setPosition((( gdjs.level_321Code.GDSpiderObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects1[0].getPointX("")),(( gdjs.level_321Code.GDSpiderObjects1.length === 0 ) ? 0 :gdjs.level_321Code.GDSpiderObjects1[0].getPointY("")) - 25);
}
}}

}


};

gdjs.level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level_321Code.GDsettings_9595iconObjects1.length = 0;
gdjs.level_321Code.GDsettings_9595iconObjects2.length = 0;
gdjs.level_321Code.GDsettings_9595iconObjects3.length = 0;
gdjs.level_321Code.GDsettings_9595iconObjects4.length = 0;
gdjs.level_321Code.GDsettings_9595iconObjects5.length = 0;
gdjs.level_321Code.GDsettingsPageOutlineObjects1.length = 0;
gdjs.level_321Code.GDsettingsPageOutlineObjects2.length = 0;
gdjs.level_321Code.GDsettingsPageOutlineObjects3.length = 0;
gdjs.level_321Code.GDsettingsPageOutlineObjects4.length = 0;
gdjs.level_321Code.GDsettingsPageOutlineObjects5.length = 0;
gdjs.level_321Code.GDmstrVolTextObjects1.length = 0;
gdjs.level_321Code.GDmstrVolTextObjects2.length = 0;
gdjs.level_321Code.GDmstrVolTextObjects3.length = 0;
gdjs.level_321Code.GDmstrVolTextObjects4.length = 0;
gdjs.level_321Code.GDmstrVolTextObjects5.length = 0;
gdjs.level_321Code.GDmstrVolSliderObjects1.length = 0;
gdjs.level_321Code.GDmstrVolSliderObjects2.length = 0;
gdjs.level_321Code.GDmstrVolSliderObjects3.length = 0;
gdjs.level_321Code.GDmstrVolSliderObjects4.length = 0;
gdjs.level_321Code.GDmstrVolSliderObjects5.length = 0;
gdjs.level_321Code.GDmstrVolValueObjects1.length = 0;
gdjs.level_321Code.GDmstrVolValueObjects2.length = 0;
gdjs.level_321Code.GDmstrVolValueObjects3.length = 0;
gdjs.level_321Code.GDmstrVolValueObjects4.length = 0;
gdjs.level_321Code.GDmstrVolValueObjects5.length = 0;
gdjs.level_321Code.GDbgMusicVolTextObjects1.length = 0;
gdjs.level_321Code.GDbgMusicVolTextObjects2.length = 0;
gdjs.level_321Code.GDbgMusicVolTextObjects3.length = 0;
gdjs.level_321Code.GDbgMusicVolTextObjects4.length = 0;
gdjs.level_321Code.GDbgMusicVolTextObjects5.length = 0;
gdjs.level_321Code.GDsndEfctsVolTextObjects1.length = 0;
gdjs.level_321Code.GDsndEfctsVolTextObjects2.length = 0;
gdjs.level_321Code.GDsndEfctsVolTextObjects3.length = 0;
gdjs.level_321Code.GDsndEfctsVolTextObjects4.length = 0;
gdjs.level_321Code.GDsndEfctsVolTextObjects5.length = 0;
gdjs.level_321Code.GDsndEffctsVolSliderObjects1.length = 0;
gdjs.level_321Code.GDsndEffctsVolSliderObjects2.length = 0;
gdjs.level_321Code.GDsndEffctsVolSliderObjects3.length = 0;
gdjs.level_321Code.GDsndEffctsVolSliderObjects4.length = 0;
gdjs.level_321Code.GDsndEffctsVolSliderObjects5.length = 0;
gdjs.level_321Code.GDbgMusicVolSliderObjects1.length = 0;
gdjs.level_321Code.GDbgMusicVolSliderObjects2.length = 0;
gdjs.level_321Code.GDbgMusicVolSliderObjects3.length = 0;
gdjs.level_321Code.GDbgMusicVolSliderObjects4.length = 0;
gdjs.level_321Code.GDbgMusicVolSliderObjects5.length = 0;
gdjs.level_321Code.GDsndEffectsVolValueObjects1.length = 0;
gdjs.level_321Code.GDsndEffectsVolValueObjects2.length = 0;
gdjs.level_321Code.GDsndEffectsVolValueObjects3.length = 0;
gdjs.level_321Code.GDsndEffectsVolValueObjects4.length = 0;
gdjs.level_321Code.GDsndEffectsVolValueObjects5.length = 0;
gdjs.level_321Code.GDbgMusicVolValueObjects1.length = 0;
gdjs.level_321Code.GDbgMusicVolValueObjects2.length = 0;
gdjs.level_321Code.GDbgMusicVolValueObjects3.length = 0;
gdjs.level_321Code.GDbgMusicVolValueObjects4.length = 0;
gdjs.level_321Code.GDbgMusicVolValueObjects5.length = 0;
gdjs.level_321Code.GDexitButtonObjects1.length = 0;
gdjs.level_321Code.GDexitButtonObjects2.length = 0;
gdjs.level_321Code.GDexitButtonObjects3.length = 0;
gdjs.level_321Code.GDexitButtonObjects4.length = 0;
gdjs.level_321Code.GDexitButtonObjects5.length = 0;
gdjs.level_321Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.level_321Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.level_321Code.GDShadedDarkJoystickObjects3.length = 0;
gdjs.level_321Code.GDShadedDarkJoystickObjects4.length = 0;
gdjs.level_321Code.GDShadedDarkJoystickObjects5.length = 0;
gdjs.level_321Code.GDJumpObjects1.length = 0;
gdjs.level_321Code.GDJumpObjects2.length = 0;
gdjs.level_321Code.GDJumpObjects3.length = 0;
gdjs.level_321Code.GDJumpObjects4.length = 0;
gdjs.level_321Code.GDJumpObjects5.length = 0;
gdjs.level_321Code.GDSlideObjects1.length = 0;
gdjs.level_321Code.GDSlideObjects2.length = 0;
gdjs.level_321Code.GDSlideObjects3.length = 0;
gdjs.level_321Code.GDSlideObjects4.length = 0;
gdjs.level_321Code.GDSlideObjects5.length = 0;
gdjs.level_321Code.GDlaternObjects1.length = 0;
gdjs.level_321Code.GDlaternObjects2.length = 0;
gdjs.level_321Code.GDlaternObjects3.length = 0;
gdjs.level_321Code.GDlaternObjects4.length = 0;
gdjs.level_321Code.GDlaternObjects5.length = 0;
gdjs.level_321Code.GDarrowObjects1.length = 0;
gdjs.level_321Code.GDarrowObjects2.length = 0;
gdjs.level_321Code.GDarrowObjects3.length = 0;
gdjs.level_321Code.GDarrowObjects4.length = 0;
gdjs.level_321Code.GDarrowObjects5.length = 0;
gdjs.level_321Code.GDMaleCharacter10Objects1.length = 0;
gdjs.level_321Code.GDMaleCharacter10Objects2.length = 0;
gdjs.level_321Code.GDMaleCharacter10Objects3.length = 0;
gdjs.level_321Code.GDMaleCharacter10Objects4.length = 0;
gdjs.level_321Code.GDMaleCharacter10Objects5.length = 0;
gdjs.level_321Code.GDFlameObjects1.length = 0;
gdjs.level_321Code.GDFlameObjects2.length = 0;
gdjs.level_321Code.GDFlameObjects3.length = 0;
gdjs.level_321Code.GDFlameObjects4.length = 0;
gdjs.level_321Code.GDFlameObjects5.length = 0;
gdjs.level_321Code.GDExplosion1Objects1.length = 0;
gdjs.level_321Code.GDExplosion1Objects2.length = 0;
gdjs.level_321Code.GDExplosion1Objects3.length = 0;
gdjs.level_321Code.GDExplosion1Objects4.length = 0;
gdjs.level_321Code.GDExplosion1Objects5.length = 0;
gdjs.level_321Code.GDaimLineObjects1.length = 0;
gdjs.level_321Code.GDaimLineObjects2.length = 0;
gdjs.level_321Code.GDaimLineObjects3.length = 0;
gdjs.level_321Code.GDaimLineObjects4.length = 0;
gdjs.level_321Code.GDaimLineObjects5.length = 0;
gdjs.level_321Code.GDmousePosObjects1.length = 0;
gdjs.level_321Code.GDmousePosObjects2.length = 0;
gdjs.level_321Code.GDmousePosObjects3.length = 0;
gdjs.level_321Code.GDmousePosObjects4.length = 0;
gdjs.level_321Code.GDmousePosObjects5.length = 0;
gdjs.level_321Code.GDlineObjects1.length = 0;
gdjs.level_321Code.GDlineObjects2.length = 0;
gdjs.level_321Code.GDlineObjects3.length = 0;
gdjs.level_321Code.GDlineObjects4.length = 0;
gdjs.level_321Code.GDlineObjects5.length = 0;
gdjs.level_321Code.GDground1Objects1.length = 0;
gdjs.level_321Code.GDground1Objects2.length = 0;
gdjs.level_321Code.GDground1Objects3.length = 0;
gdjs.level_321Code.GDground1Objects4.length = 0;
gdjs.level_321Code.GDground1Objects5.length = 0;
gdjs.level_321Code.GDZombieObjects1.length = 0;
gdjs.level_321Code.GDZombieObjects2.length = 0;
gdjs.level_321Code.GDZombieObjects3.length = 0;
gdjs.level_321Code.GDZombieObjects4.length = 0;
gdjs.level_321Code.GDZombieObjects5.length = 0;
gdjs.level_321Code.GDSpiderObjects1.length = 0;
gdjs.level_321Code.GDSpiderObjects2.length = 0;
gdjs.level_321Code.GDSpiderObjects3.length = 0;
gdjs.level_321Code.GDSpiderObjects4.length = 0;
gdjs.level_321Code.GDSpiderObjects5.length = 0;
gdjs.level_321Code.GDbatObjects1.length = 0;
gdjs.level_321Code.GDbatObjects2.length = 0;
gdjs.level_321Code.GDbatObjects3.length = 0;
gdjs.level_321Code.GDbatObjects4.length = 0;
gdjs.level_321Code.GDbatObjects5.length = 0;
gdjs.level_321Code.GDcheckpointObjects1.length = 0;
gdjs.level_321Code.GDcheckpointObjects2.length = 0;
gdjs.level_321Code.GDcheckpointObjects3.length = 0;
gdjs.level_321Code.GDcheckpointObjects4.length = 0;
gdjs.level_321Code.GDcheckpointObjects5.length = 0;
gdjs.level_321Code.GDtransistionObjects1.length = 0;
gdjs.level_321Code.GDtransistionObjects2.length = 0;
gdjs.level_321Code.GDtransistionObjects3.length = 0;
gdjs.level_321Code.GDtransistionObjects4.length = 0;
gdjs.level_321Code.GDtransistionObjects5.length = 0;
gdjs.level_321Code.GDdeathCountTextObjects1.length = 0;
gdjs.level_321Code.GDdeathCountTextObjects2.length = 0;
gdjs.level_321Code.GDdeathCountTextObjects3.length = 0;
gdjs.level_321Code.GDdeathCountTextObjects4.length = 0;
gdjs.level_321Code.GDdeathCountTextObjects5.length = 0;
gdjs.level_321Code.GDkillLineObjects1.length = 0;
gdjs.level_321Code.GDkillLineObjects2.length = 0;
gdjs.level_321Code.GDkillLineObjects3.length = 0;
gdjs.level_321Code.GDkillLineObjects4.length = 0;
gdjs.level_321Code.GDkillLineObjects5.length = 0;
gdjs.level_321Code.GDheartBarObjects1.length = 0;
gdjs.level_321Code.GDheartBarObjects2.length = 0;
gdjs.level_321Code.GDheartBarObjects3.length = 0;
gdjs.level_321Code.GDheartBarObjects4.length = 0;
gdjs.level_321Code.GDheartBarObjects5.length = 0;
gdjs.level_321Code.GDlanternFuelBarObjects1.length = 0;
gdjs.level_321Code.GDlanternFuelBarObjects2.length = 0;
gdjs.level_321Code.GDlanternFuelBarObjects3.length = 0;
gdjs.level_321Code.GDlanternFuelBarObjects4.length = 0;
gdjs.level_321Code.GDlanternFuelBarObjects5.length = 0;
gdjs.level_321Code.GDzombieHealthObjects1.length = 0;
gdjs.level_321Code.GDzombieHealthObjects2.length = 0;
gdjs.level_321Code.GDzombieHealthObjects3.length = 0;
gdjs.level_321Code.GDzombieHealthObjects4.length = 0;
gdjs.level_321Code.GDzombieHealthObjects5.length = 0;
gdjs.level_321Code.GDdamageObjects1.length = 0;
gdjs.level_321Code.GDdamageObjects2.length = 0;
gdjs.level_321Code.GDdamageObjects3.length = 0;
gdjs.level_321Code.GDdamageObjects4.length = 0;
gdjs.level_321Code.GDdamageObjects5.length = 0;
gdjs.level_321Code.GDlaywerObjects1.length = 0;
gdjs.level_321Code.GDlaywerObjects2.length = 0;
gdjs.level_321Code.GDlaywerObjects3.length = 0;
gdjs.level_321Code.GDlaywerObjects4.length = 0;
gdjs.level_321Code.GDlaywerObjects5.length = 0;
gdjs.level_321Code.GDbreifcaseObjects1.length = 0;
gdjs.level_321Code.GDbreifcaseObjects2.length = 0;
gdjs.level_321Code.GDbreifcaseObjects3.length = 0;
gdjs.level_321Code.GDbreifcaseObjects4.length = 0;
gdjs.level_321Code.GDbreifcaseObjects5.length = 0;
gdjs.level_321Code.GDfallingPlatformObjects1.length = 0;
gdjs.level_321Code.GDfallingPlatformObjects2.length = 0;
gdjs.level_321Code.GDfallingPlatformObjects3.length = 0;
gdjs.level_321Code.GDfallingPlatformObjects4.length = 0;
gdjs.level_321Code.GDfallingPlatformObjects5.length = 0;
gdjs.level_321Code.GDlaywerHealthBarObjects1.length = 0;
gdjs.level_321Code.GDlaywerHealthBarObjects2.length = 0;
gdjs.level_321Code.GDlaywerHealthBarObjects3.length = 0;
gdjs.level_321Code.GDlaywerHealthBarObjects4.length = 0;
gdjs.level_321Code.GDlaywerHealthBarObjects5.length = 0;
gdjs.level_321Code.GDbarn_9595interior_95951Objects1.length = 0;
gdjs.level_321Code.GDbarn_9595interior_95951Objects2.length = 0;
gdjs.level_321Code.GDbarn_9595interior_95951Objects3.length = 0;
gdjs.level_321Code.GDbarn_9595interior_95951Objects4.length = 0;
gdjs.level_321Code.GDbarn_9595interior_95951Objects5.length = 0;
gdjs.level_321Code.GDsky1Objects1.length = 0;
gdjs.level_321Code.GDsky1Objects2.length = 0;
gdjs.level_321Code.GDsky1Objects3.length = 0;
gdjs.level_321Code.GDsky1Objects4.length = 0;
gdjs.level_321Code.GDsky1Objects5.length = 0;
gdjs.level_321Code.GDlavaObjects1.length = 0;
gdjs.level_321Code.GDlavaObjects2.length = 0;
gdjs.level_321Code.GDlavaObjects3.length = 0;
gdjs.level_321Code.GDlavaObjects4.length = 0;
gdjs.level_321Code.GDlavaObjects5.length = 0;
gdjs.level_321Code.GDspiderHealthObjects1.length = 0;
gdjs.level_321Code.GDspiderHealthObjects2.length = 0;
gdjs.level_321Code.GDspiderHealthObjects3.length = 0;
gdjs.level_321Code.GDspiderHealthObjects4.length = 0;
gdjs.level_321Code.GDspiderHealthObjects5.length = 0;
gdjs.level_321Code.GDWillyObjects1.length = 0;
gdjs.level_321Code.GDWillyObjects2.length = 0;
gdjs.level_321Code.GDWillyObjects3.length = 0;
gdjs.level_321Code.GDWillyObjects4.length = 0;
gdjs.level_321Code.GDWillyObjects5.length = 0;
gdjs.level_321Code.GDWillyHeadObjects1.length = 0;
gdjs.level_321Code.GDWillyHeadObjects2.length = 0;
gdjs.level_321Code.GDWillyHeadObjects3.length = 0;
gdjs.level_321Code.GDWillyHeadObjects4.length = 0;
gdjs.level_321Code.GDWillyHeadObjects5.length = 0;
gdjs.level_321Code.GDWillyLowerRightLegObjects1.length = 0;
gdjs.level_321Code.GDWillyLowerRightLegObjects2.length = 0;
gdjs.level_321Code.GDWillyLowerRightLegObjects3.length = 0;
gdjs.level_321Code.GDWillyLowerRightLegObjects4.length = 0;
gdjs.level_321Code.GDWillyLowerRightLegObjects5.length = 0;
gdjs.level_321Code.GDWillyUpperRightLegObjects1.length = 0;
gdjs.level_321Code.GDWillyUpperRightLegObjects2.length = 0;
gdjs.level_321Code.GDWillyUpperRightLegObjects3.length = 0;
gdjs.level_321Code.GDWillyUpperRightLegObjects4.length = 0;
gdjs.level_321Code.GDWillyUpperRightLegObjects5.length = 0;
gdjs.level_321Code.GDWillyUpperLeftLegObjects1.length = 0;
gdjs.level_321Code.GDWillyUpperLeftLegObjects2.length = 0;
gdjs.level_321Code.GDWillyUpperLeftLegObjects3.length = 0;
gdjs.level_321Code.GDWillyUpperLeftLegObjects4.length = 0;
gdjs.level_321Code.GDWillyUpperLeftLegObjects5.length = 0;
gdjs.level_321Code.GDWillyLowerLeftLegObjects1.length = 0;
gdjs.level_321Code.GDWillyLowerLeftLegObjects2.length = 0;
gdjs.level_321Code.GDWillyLowerLeftLegObjects3.length = 0;
gdjs.level_321Code.GDWillyLowerLeftLegObjects4.length = 0;
gdjs.level_321Code.GDWillyLowerLeftLegObjects5.length = 0;
gdjs.level_321Code.GDrock_9595bg_95951Objects1.length = 0;
gdjs.level_321Code.GDrock_9595bg_95951Objects2.length = 0;
gdjs.level_321Code.GDrock_9595bg_95951Objects3.length = 0;
gdjs.level_321Code.GDrock_9595bg_95951Objects4.length = 0;
gdjs.level_321Code.GDrock_9595bg_95951Objects5.length = 0;
gdjs.level_321Code.GDrock_9595bg_95952Objects1.length = 0;
gdjs.level_321Code.GDrock_9595bg_95952Objects2.length = 0;
gdjs.level_321Code.GDrock_9595bg_95952Objects3.length = 0;
gdjs.level_321Code.GDrock_9595bg_95952Objects4.length = 0;
gdjs.level_321Code.GDrock_9595bg_95952Objects5.length = 0;
gdjs.level_321Code.GDborder_95951Objects1.length = 0;
gdjs.level_321Code.GDborder_95951Objects2.length = 0;
gdjs.level_321Code.GDborder_95951Objects3.length = 0;
gdjs.level_321Code.GDborder_95951Objects4.length = 0;
gdjs.level_321Code.GDborder_95951Objects5.length = 0;
gdjs.level_321Code.GDwoodenPlatformObjects1.length = 0;
gdjs.level_321Code.GDwoodenPlatformObjects2.length = 0;
gdjs.level_321Code.GDwoodenPlatformObjects3.length = 0;
gdjs.level_321Code.GDwoodenPlatformObjects4.length = 0;
gdjs.level_321Code.GDwoodenPlatformObjects5.length = 0;
gdjs.level_321Code.GDboxObjects1.length = 0;
gdjs.level_321Code.GDboxObjects2.length = 0;
gdjs.level_321Code.GDboxObjects3.length = 0;
gdjs.level_321Code.GDboxObjects4.length = 0;
gdjs.level_321Code.GDboxObjects5.length = 0;
gdjs.level_321Code.GDfanObjects1.length = 0;
gdjs.level_321Code.GDfanObjects2.length = 0;
gdjs.level_321Code.GDfanObjects3.length = 0;
gdjs.level_321Code.GDfanObjects4.length = 0;
gdjs.level_321Code.GDfanObjects5.length = 0;
gdjs.level_321Code.GDchestObjects1.length = 0;
gdjs.level_321Code.GDchestObjects2.length = 0;
gdjs.level_321Code.GDchestObjects3.length = 0;
gdjs.level_321Code.GDchestObjects4.length = 0;
gdjs.level_321Code.GDchestObjects5.length = 0;
gdjs.level_321Code.GDfire_9595keybindObjects1.length = 0;
gdjs.level_321Code.GDfire_9595keybindObjects2.length = 0;
gdjs.level_321Code.GDfire_9595keybindObjects3.length = 0;
gdjs.level_321Code.GDfire_9595keybindObjects4.length = 0;
gdjs.level_321Code.GDfire_9595keybindObjects5.length = 0;
gdjs.level_321Code.GDfireButtonObjects1.length = 0;
gdjs.level_321Code.GDfireButtonObjects2.length = 0;
gdjs.level_321Code.GDfireButtonObjects3.length = 0;
gdjs.level_321Code.GDfireButtonObjects4.length = 0;
gdjs.level_321Code.GDfireButtonObjects5.length = 0;
gdjs.level_321Code.GDmineshaftObjects1.length = 0;
gdjs.level_321Code.GDmineshaftObjects2.length = 0;
gdjs.level_321Code.GDmineshaftObjects3.length = 0;
gdjs.level_321Code.GDmineshaftObjects4.length = 0;
gdjs.level_321Code.GDmineshaftObjects5.length = 0;
gdjs.level_321Code.GDNewSpriteObjects1.length = 0;
gdjs.level_321Code.GDNewSpriteObjects2.length = 0;
gdjs.level_321Code.GDNewSpriteObjects3.length = 0;
gdjs.level_321Code.GDNewSpriteObjects4.length = 0;
gdjs.level_321Code.GDNewSpriteObjects5.length = 0;
gdjs.level_321Code.GDbig_9595rock_95951Objects1.length = 0;
gdjs.level_321Code.GDbig_9595rock_95951Objects2.length = 0;
gdjs.level_321Code.GDbig_9595rock_95951Objects3.length = 0;
gdjs.level_321Code.GDbig_9595rock_95951Objects4.length = 0;
gdjs.level_321Code.GDbig_9595rock_95951Objects5.length = 0;
gdjs.level_321Code.GDbig_9595rock_95952Objects1.length = 0;
gdjs.level_321Code.GDbig_9595rock_95952Objects2.length = 0;
gdjs.level_321Code.GDbig_9595rock_95952Objects3.length = 0;
gdjs.level_321Code.GDbig_9595rock_95952Objects4.length = 0;
gdjs.level_321Code.GDbig_9595rock_95952Objects5.length = 0;
gdjs.level_321Code.GDbig_9595rock_95953Objects1.length = 0;
gdjs.level_321Code.GDbig_9595rock_95953Objects2.length = 0;
gdjs.level_321Code.GDbig_9595rock_95953Objects3.length = 0;
gdjs.level_321Code.GDbig_9595rock_95953Objects4.length = 0;
gdjs.level_321Code.GDbig_9595rock_95953Objects5.length = 0;
gdjs.level_321Code.GDsmall_9595rock_95951Objects1.length = 0;
gdjs.level_321Code.GDsmall_9595rock_95951Objects2.length = 0;
gdjs.level_321Code.GDsmall_9595rock_95951Objects3.length = 0;
gdjs.level_321Code.GDsmall_9595rock_95951Objects4.length = 0;
gdjs.level_321Code.GDsmall_9595rock_95951Objects5.length = 0;
gdjs.level_321Code.GDNewSprite2Objects1.length = 0;
gdjs.level_321Code.GDNewSprite2Objects2.length = 0;
gdjs.level_321Code.GDNewSprite2Objects3.length = 0;
gdjs.level_321Code.GDNewSprite2Objects4.length = 0;
gdjs.level_321Code.GDNewSprite2Objects5.length = 0;
gdjs.level_321Code.GDrocksObjects1.length = 0;
gdjs.level_321Code.GDrocksObjects2.length = 0;
gdjs.level_321Code.GDrocksObjects3.length = 0;
gdjs.level_321Code.GDrocksObjects4.length = 0;
gdjs.level_321Code.GDrocksObjects5.length = 0;
gdjs.level_321Code.GDmazeObjects1.length = 0;
gdjs.level_321Code.GDmazeObjects2.length = 0;
gdjs.level_321Code.GDmazeObjects3.length = 0;
gdjs.level_321Code.GDmazeObjects4.length = 0;
gdjs.level_321Code.GDmazeObjects5.length = 0;
gdjs.level_321Code.GD_95950003_95956Objects1.length = 0;
gdjs.level_321Code.GD_95950003_95956Objects2.length = 0;
gdjs.level_321Code.GD_95950003_95956Objects3.length = 0;
gdjs.level_321Code.GD_95950003_95956Objects4.length = 0;
gdjs.level_321Code.GD_95950003_95956Objects5.length = 0;
gdjs.level_321Code.GD_95950008_95953Objects1.length = 0;
gdjs.level_321Code.GD_95950008_95953Objects2.length = 0;
gdjs.level_321Code.GD_95950008_95953Objects3.length = 0;
gdjs.level_321Code.GD_95950008_95953Objects4.length = 0;
gdjs.level_321Code.GD_95950008_95953Objects5.length = 0;
gdjs.level_321Code.GD_95950010_95951Objects1.length = 0;
gdjs.level_321Code.GD_95950010_95951Objects2.length = 0;
gdjs.level_321Code.GD_95950010_95951Objects3.length = 0;
gdjs.level_321Code.GD_95950010_95951Objects4.length = 0;
gdjs.level_321Code.GD_95950010_95951Objects5.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects4.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects5.length = 0;
gdjs.level_321Code.GDmilkObjects1.length = 0;
gdjs.level_321Code.GDmilkObjects2.length = 0;
gdjs.level_321Code.GDmilkObjects3.length = 0;
gdjs.level_321Code.GDmilkObjects4.length = 0;
gdjs.level_321Code.GDmilkObjects5.length = 0;
gdjs.level_321Code.GDplayerObjects1.length = 0;
gdjs.level_321Code.GDplayerObjects2.length = 0;
gdjs.level_321Code.GDplayerObjects3.length = 0;
gdjs.level_321Code.GDplayerObjects4.length = 0;
gdjs.level_321Code.GDplayerObjects5.length = 0;
gdjs.level_321Code.GDghostObjects1.length = 0;
gdjs.level_321Code.GDghostObjects2.length = 0;
gdjs.level_321Code.GDghostObjects3.length = 0;
gdjs.level_321Code.GDghostObjects4.length = 0;
gdjs.level_321Code.GDghostObjects5.length = 0;

gdjs.level_321Code.eventsList40(runtimeScene);

return;

}

gdjs['level_321Code'] = gdjs.level_321Code;
