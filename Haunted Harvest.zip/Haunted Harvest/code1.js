gdjs.tutorialCode = {};
gdjs.tutorialCode.localVariables = [];
gdjs.tutorialCode.GDNewSpriteObjects1= [];
gdjs.tutorialCode.GDNewSpriteObjects2= [];
gdjs.tutorialCode.GDNewSpriteObjects3= [];
gdjs.tutorialCode.GDNewSpriteObjects4= [];
gdjs.tutorialCode.GDNewSpriteObjects5= [];
gdjs.tutorialCode.GDground1Objects1= [];
gdjs.tutorialCode.GDground1Objects2= [];
gdjs.tutorialCode.GDground1Objects3= [];
gdjs.tutorialCode.GDground1Objects4= [];
gdjs.tutorialCode.GDground1Objects5= [];
gdjs.tutorialCode.GDfallingPlatformObjects1= [];
gdjs.tutorialCode.GDfallingPlatformObjects2= [];
gdjs.tutorialCode.GDfallingPlatformObjects3= [];
gdjs.tutorialCode.GDfallingPlatformObjects4= [];
gdjs.tutorialCode.GDfallingPlatformObjects5= [];
gdjs.tutorialCode.GDwoodenPlatformObjects1= [];
gdjs.tutorialCode.GDwoodenPlatformObjects2= [];
gdjs.tutorialCode.GDwoodenPlatformObjects3= [];
gdjs.tutorialCode.GDwoodenPlatformObjects4= [];
gdjs.tutorialCode.GDwoodenPlatformObjects5= [];
gdjs.tutorialCode.GDZombieObjects1= [];
gdjs.tutorialCode.GDZombieObjects2= [];
gdjs.tutorialCode.GDZombieObjects3= [];
gdjs.tutorialCode.GDZombieObjects4= [];
gdjs.tutorialCode.GDZombieObjects5= [];
gdjs.tutorialCode.GDSpiderObjects1= [];
gdjs.tutorialCode.GDSpiderObjects2= [];
gdjs.tutorialCode.GDSpiderObjects3= [];
gdjs.tutorialCode.GDSpiderObjects4= [];
gdjs.tutorialCode.GDSpiderObjects5= [];
gdjs.tutorialCode.GDlaywerObjects1= [];
gdjs.tutorialCode.GDlaywerObjects2= [];
gdjs.tutorialCode.GDlaywerObjects3= [];
gdjs.tutorialCode.GDlaywerObjects4= [];
gdjs.tutorialCode.GDlaywerObjects5= [];
gdjs.tutorialCode.GDbreifcaseObjects1= [];
gdjs.tutorialCode.GDbreifcaseObjects2= [];
gdjs.tutorialCode.GDbreifcaseObjects3= [];
gdjs.tutorialCode.GDbreifcaseObjects4= [];
gdjs.tutorialCode.GDbreifcaseObjects5= [];
gdjs.tutorialCode.GDheartBarObjects1= [];
gdjs.tutorialCode.GDheartBarObjects2= [];
gdjs.tutorialCode.GDheartBarObjects3= [];
gdjs.tutorialCode.GDheartBarObjects4= [];
gdjs.tutorialCode.GDheartBarObjects5= [];
gdjs.tutorialCode.GDlanternFuelBarObjects1= [];
gdjs.tutorialCode.GDlanternFuelBarObjects2= [];
gdjs.tutorialCode.GDlanternFuelBarObjects3= [];
gdjs.tutorialCode.GDlanternFuelBarObjects4= [];
gdjs.tutorialCode.GDlanternFuelBarObjects5= [];
gdjs.tutorialCode.GDjailCellObjects1= [];
gdjs.tutorialCode.GDjailCellObjects2= [];
gdjs.tutorialCode.GDjailCellObjects3= [];
gdjs.tutorialCode.GDjailCellObjects4= [];
gdjs.tutorialCode.GDjailCellObjects5= [];
gdjs.tutorialCode.GDspider_9595textObjects1= [];
gdjs.tutorialCode.GDspider_9595textObjects2= [];
gdjs.tutorialCode.GDspider_9595textObjects3= [];
gdjs.tutorialCode.GDspider_9595textObjects4= [];
gdjs.tutorialCode.GDspider_9595textObjects5= [];
gdjs.tutorialCode.GDlawyer_9595textObjects1= [];
gdjs.tutorialCode.GDlawyer_9595textObjects2= [];
gdjs.tutorialCode.GDlawyer_9595textObjects3= [];
gdjs.tutorialCode.GDlawyer_9595textObjects4= [];
gdjs.tutorialCode.GDlawyer_9595textObjects5= [];
gdjs.tutorialCode.GDzombie_9595textObjects1= [];
gdjs.tutorialCode.GDzombie_9595textObjects2= [];
gdjs.tutorialCode.GDzombie_9595textObjects3= [];
gdjs.tutorialCode.GDzombie_9595textObjects4= [];
gdjs.tutorialCode.GDzombie_9595textObjects5= [];
gdjs.tutorialCode.GDJumpObjects1= [];
gdjs.tutorialCode.GDJumpObjects2= [];
gdjs.tutorialCode.GDJumpObjects3= [];
gdjs.tutorialCode.GDJumpObjects4= [];
gdjs.tutorialCode.GDJumpObjects5= [];
gdjs.tutorialCode.GDSlideObjects1= [];
gdjs.tutorialCode.GDSlideObjects2= [];
gdjs.tutorialCode.GDSlideObjects3= [];
gdjs.tutorialCode.GDSlideObjects4= [];
gdjs.tutorialCode.GDSlideObjects5= [];
gdjs.tutorialCode.GDShadedDarkJoystickObjects1= [];
gdjs.tutorialCode.GDShadedDarkJoystickObjects2= [];
gdjs.tutorialCode.GDShadedDarkJoystickObjects3= [];
gdjs.tutorialCode.GDShadedDarkJoystickObjects4= [];
gdjs.tutorialCode.GDShadedDarkJoystickObjects5= [];
gdjs.tutorialCode.GDbuttonObjects1= [];
gdjs.tutorialCode.GDbuttonObjects2= [];
gdjs.tutorialCode.GDbuttonObjects3= [];
gdjs.tutorialCode.GDbuttonObjects4= [];
gdjs.tutorialCode.GDbuttonObjects5= [];
gdjs.tutorialCode.GDbutton_9595textObjects1= [];
gdjs.tutorialCode.GDbutton_9595textObjects2= [];
gdjs.tutorialCode.GDbutton_9595textObjects3= [];
gdjs.tutorialCode.GDbutton_9595textObjects4= [];
gdjs.tutorialCode.GDbutton_9595textObjects5= [];
gdjs.tutorialCode.GDkeybindsObjects1= [];
gdjs.tutorialCode.GDkeybindsObjects2= [];
gdjs.tutorialCode.GDkeybindsObjects3= [];
gdjs.tutorialCode.GDkeybindsObjects4= [];
gdjs.tutorialCode.GDkeybindsObjects5= [];
gdjs.tutorialCode.GDbarrierObjects1= [];
gdjs.tutorialCode.GDbarrierObjects2= [];
gdjs.tutorialCode.GDbarrierObjects3= [];
gdjs.tutorialCode.GDbarrierObjects4= [];
gdjs.tutorialCode.GDbarrierObjects5= [];
gdjs.tutorialCode.GDplayerObjects1= [];
gdjs.tutorialCode.GDplayerObjects2= [];
gdjs.tutorialCode.GDplayerObjects3= [];
gdjs.tutorialCode.GDplayerObjects4= [];
gdjs.tutorialCode.GDplayerObjects5= [];
gdjs.tutorialCode.GDghostObjects1= [];
gdjs.tutorialCode.GDghostObjects2= [];
gdjs.tutorialCode.GDghostObjects3= [];
gdjs.tutorialCode.GDghostObjects4= [];
gdjs.tutorialCode.GDghostObjects5= [];


gdjs.tutorialCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "MobileControls");
}}

}


};gdjs.tutorialCode.asyncCallback24142364 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.tutorialCode.localVariables);
gdjs.tutorialCode.localVariables.length = 0;
}
gdjs.tutorialCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.tutorialCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.tutorialCode.asyncCallback24142364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.tutorialCode.asyncCallback24141772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.tutorialCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.tutorialCode.GDplayerObjects4);

{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects4.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects4[i].getBehavior("Animation").setAnimationName("Idle");
}
}
{ //Subevents
gdjs.tutorialCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.tutorialCode.localVariables.length = 0;
}
gdjs.tutorialCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.tutorialCode.localVariables);
for (const obj of gdjs.tutorialCode.GDplayerObjects3) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.tutorialCode.asyncCallback24141772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.tutorialCode.asyncCallback24141276 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.tutorialCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.tutorialCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects3[i].getBehavior("Animation").setAnimationName("Fall");
}
}
{ //Subevents
gdjs.tutorialCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.tutorialCode.localVariables.length = 0;
}
gdjs.tutorialCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.tutorialCode.localVariables);
for (const obj of gdjs.tutorialCode.GDplayerObjects2) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.tutorialCode.asyncCallback24141276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.tutorialCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.tutorialCode.GDplayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.tutorialCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("HorizontalDash").IsDashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.tutorialCode.GDplayerObjects2[k] = gdjs.tutorialCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.tutorialCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.tutorialCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("Dash");
}
}
{ //Subevents
gdjs.tutorialCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.tutorialCode.asyncCallback24145588 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.tutorialCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);

{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}gdjs.tutorialCode.localVariables.length = 0;
}
gdjs.tutorialCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.tutorialCode.localVariables);
for (const obj of gdjs.tutorialCode.GDplayerObjects1) asyncObjectsList.addObject("player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.tutorialCode.asyncCallback24145588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.tutorialCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.tutorialCode.GDghostObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.tutorialCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDghostObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.tutorialCode.GDghostObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.tutorialCode.GDghostObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDghostObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.tutorialCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.tutorialCode.GDJumpObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.tutorialCode.GDJumpObjects2.length;i<l;++i) {
    if ( gdjs.tutorialCode.GDJumpObjects2[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.tutorialCode.GDJumpObjects2[k] = gdjs.tutorialCode.GDJumpObjects2[i];
        ++k;
    }
}
gdjs.tutorialCode.GDJumpObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects2[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slide"), gdjs.tutorialCode.GDSlideObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.tutorialCode.GDSlideObjects1.length;i<l;++i) {
    if ( gdjs.tutorialCode.GDSlideObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.tutorialCode.GDSlideObjects1[k] = gdjs.tutorialCode.GDSlideObjects1[i];
        ++k;
    }
}
gdjs.tutorialCode.GDSlideObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(24144356);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects1[i].getBehavior("HorizontalDash").SimulateDashKey((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.tutorialCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.tutorialCode.GDplayerObjects1[i].getBehavior("Animation").setAnimationName("Dash");
}
}
{ //Subevents
gdjs.tutorialCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.tutorialCode.mapOfGDgdjs_9546tutorialCode_9546GDbuttonObjects1Objects = Hashtable.newFrom({"button": gdjs.tutorialCode.GDbuttonObjects1});
gdjs.tutorialCode.mapOfGDgdjs_9546tutorialCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.tutorialCode.GDplayerObjects1});
gdjs.tutorialCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.tutorialCode.GDbarrierObjects1);
{gdjs.evtTools.advancedWindow.maximize(true, runtimeScene);
}{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.25, "", 0);
}{for(var i = 0, len = gdjs.tutorialCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.tutorialCode.GDbarrierObjects1[i].hide();
}
}
{ //Subevents
gdjs.tutorialCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.tutorialCode.eventsList6(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("button"), gdjs.tutorialCode.GDbuttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.tutorialCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.tutorialCode.mapOfGDgdjs_9546tutorialCode_9546GDbuttonObjects1Objects, gdjs.tutorialCode.mapOfGDgdjs_9546tutorialCode_9546GDplayerObjects1Objects, 20, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Tab");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 1", false);
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.clampCamera(runtimeScene, 0, 0, 1920, 1080, "", 0);
}}

}


};

gdjs.tutorialCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.tutorialCode.GDNewSpriteObjects1.length = 0;
gdjs.tutorialCode.GDNewSpriteObjects2.length = 0;
gdjs.tutorialCode.GDNewSpriteObjects3.length = 0;
gdjs.tutorialCode.GDNewSpriteObjects4.length = 0;
gdjs.tutorialCode.GDNewSpriteObjects5.length = 0;
gdjs.tutorialCode.GDground1Objects1.length = 0;
gdjs.tutorialCode.GDground1Objects2.length = 0;
gdjs.tutorialCode.GDground1Objects3.length = 0;
gdjs.tutorialCode.GDground1Objects4.length = 0;
gdjs.tutorialCode.GDground1Objects5.length = 0;
gdjs.tutorialCode.GDfallingPlatformObjects1.length = 0;
gdjs.tutorialCode.GDfallingPlatformObjects2.length = 0;
gdjs.tutorialCode.GDfallingPlatformObjects3.length = 0;
gdjs.tutorialCode.GDfallingPlatformObjects4.length = 0;
gdjs.tutorialCode.GDfallingPlatformObjects5.length = 0;
gdjs.tutorialCode.GDwoodenPlatformObjects1.length = 0;
gdjs.tutorialCode.GDwoodenPlatformObjects2.length = 0;
gdjs.tutorialCode.GDwoodenPlatformObjects3.length = 0;
gdjs.tutorialCode.GDwoodenPlatformObjects4.length = 0;
gdjs.tutorialCode.GDwoodenPlatformObjects5.length = 0;
gdjs.tutorialCode.GDZombieObjects1.length = 0;
gdjs.tutorialCode.GDZombieObjects2.length = 0;
gdjs.tutorialCode.GDZombieObjects3.length = 0;
gdjs.tutorialCode.GDZombieObjects4.length = 0;
gdjs.tutorialCode.GDZombieObjects5.length = 0;
gdjs.tutorialCode.GDSpiderObjects1.length = 0;
gdjs.tutorialCode.GDSpiderObjects2.length = 0;
gdjs.tutorialCode.GDSpiderObjects3.length = 0;
gdjs.tutorialCode.GDSpiderObjects4.length = 0;
gdjs.tutorialCode.GDSpiderObjects5.length = 0;
gdjs.tutorialCode.GDlaywerObjects1.length = 0;
gdjs.tutorialCode.GDlaywerObjects2.length = 0;
gdjs.tutorialCode.GDlaywerObjects3.length = 0;
gdjs.tutorialCode.GDlaywerObjects4.length = 0;
gdjs.tutorialCode.GDlaywerObjects5.length = 0;
gdjs.tutorialCode.GDbreifcaseObjects1.length = 0;
gdjs.tutorialCode.GDbreifcaseObjects2.length = 0;
gdjs.tutorialCode.GDbreifcaseObjects3.length = 0;
gdjs.tutorialCode.GDbreifcaseObjects4.length = 0;
gdjs.tutorialCode.GDbreifcaseObjects5.length = 0;
gdjs.tutorialCode.GDheartBarObjects1.length = 0;
gdjs.tutorialCode.GDheartBarObjects2.length = 0;
gdjs.tutorialCode.GDheartBarObjects3.length = 0;
gdjs.tutorialCode.GDheartBarObjects4.length = 0;
gdjs.tutorialCode.GDheartBarObjects5.length = 0;
gdjs.tutorialCode.GDlanternFuelBarObjects1.length = 0;
gdjs.tutorialCode.GDlanternFuelBarObjects2.length = 0;
gdjs.tutorialCode.GDlanternFuelBarObjects3.length = 0;
gdjs.tutorialCode.GDlanternFuelBarObjects4.length = 0;
gdjs.tutorialCode.GDlanternFuelBarObjects5.length = 0;
gdjs.tutorialCode.GDjailCellObjects1.length = 0;
gdjs.tutorialCode.GDjailCellObjects2.length = 0;
gdjs.tutorialCode.GDjailCellObjects3.length = 0;
gdjs.tutorialCode.GDjailCellObjects4.length = 0;
gdjs.tutorialCode.GDjailCellObjects5.length = 0;
gdjs.tutorialCode.GDspider_9595textObjects1.length = 0;
gdjs.tutorialCode.GDspider_9595textObjects2.length = 0;
gdjs.tutorialCode.GDspider_9595textObjects3.length = 0;
gdjs.tutorialCode.GDspider_9595textObjects4.length = 0;
gdjs.tutorialCode.GDspider_9595textObjects5.length = 0;
gdjs.tutorialCode.GDlawyer_9595textObjects1.length = 0;
gdjs.tutorialCode.GDlawyer_9595textObjects2.length = 0;
gdjs.tutorialCode.GDlawyer_9595textObjects3.length = 0;
gdjs.tutorialCode.GDlawyer_9595textObjects4.length = 0;
gdjs.tutorialCode.GDlawyer_9595textObjects5.length = 0;
gdjs.tutorialCode.GDzombie_9595textObjects1.length = 0;
gdjs.tutorialCode.GDzombie_9595textObjects2.length = 0;
gdjs.tutorialCode.GDzombie_9595textObjects3.length = 0;
gdjs.tutorialCode.GDzombie_9595textObjects4.length = 0;
gdjs.tutorialCode.GDzombie_9595textObjects5.length = 0;
gdjs.tutorialCode.GDJumpObjects1.length = 0;
gdjs.tutorialCode.GDJumpObjects2.length = 0;
gdjs.tutorialCode.GDJumpObjects3.length = 0;
gdjs.tutorialCode.GDJumpObjects4.length = 0;
gdjs.tutorialCode.GDJumpObjects5.length = 0;
gdjs.tutorialCode.GDSlideObjects1.length = 0;
gdjs.tutorialCode.GDSlideObjects2.length = 0;
gdjs.tutorialCode.GDSlideObjects3.length = 0;
gdjs.tutorialCode.GDSlideObjects4.length = 0;
gdjs.tutorialCode.GDSlideObjects5.length = 0;
gdjs.tutorialCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.tutorialCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.tutorialCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.tutorialCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.tutorialCode.GDShadedDarkJoystickObjects5.length = 0;
gdjs.tutorialCode.GDbuttonObjects1.length = 0;
gdjs.tutorialCode.GDbuttonObjects2.length = 0;
gdjs.tutorialCode.GDbuttonObjects3.length = 0;
gdjs.tutorialCode.GDbuttonObjects4.length = 0;
gdjs.tutorialCode.GDbuttonObjects5.length = 0;
gdjs.tutorialCode.GDbutton_9595textObjects1.length = 0;
gdjs.tutorialCode.GDbutton_9595textObjects2.length = 0;
gdjs.tutorialCode.GDbutton_9595textObjects3.length = 0;
gdjs.tutorialCode.GDbutton_9595textObjects4.length = 0;
gdjs.tutorialCode.GDbutton_9595textObjects5.length = 0;
gdjs.tutorialCode.GDkeybindsObjects1.length = 0;
gdjs.tutorialCode.GDkeybindsObjects2.length = 0;
gdjs.tutorialCode.GDkeybindsObjects3.length = 0;
gdjs.tutorialCode.GDkeybindsObjects4.length = 0;
gdjs.tutorialCode.GDkeybindsObjects5.length = 0;
gdjs.tutorialCode.GDbarrierObjects1.length = 0;
gdjs.tutorialCode.GDbarrierObjects2.length = 0;
gdjs.tutorialCode.GDbarrierObjects3.length = 0;
gdjs.tutorialCode.GDbarrierObjects4.length = 0;
gdjs.tutorialCode.GDbarrierObjects5.length = 0;
gdjs.tutorialCode.GDplayerObjects1.length = 0;
gdjs.tutorialCode.GDplayerObjects2.length = 0;
gdjs.tutorialCode.GDplayerObjects3.length = 0;
gdjs.tutorialCode.GDplayerObjects4.length = 0;
gdjs.tutorialCode.GDplayerObjects5.length = 0;
gdjs.tutorialCode.GDghostObjects1.length = 0;
gdjs.tutorialCode.GDghostObjects2.length = 0;
gdjs.tutorialCode.GDghostObjects3.length = 0;
gdjs.tutorialCode.GDghostObjects4.length = 0;
gdjs.tutorialCode.GDghostObjects5.length = 0;

gdjs.tutorialCode.eventsList7(runtimeScene);

return;

}

gdjs['tutorialCode'] = gdjs.tutorialCode;
