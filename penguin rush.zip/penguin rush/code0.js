gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDRangerPortraitFullBodyObjects1= [];
gdjs.Untitled_32sceneCode.GDRangerPortraitFullBodyObjects2= [];
gdjs.Untitled_32sceneCode.GDRangerPortraitObjects1= [];
gdjs.Untitled_32sceneCode.GDRangerPortraitObjects2= [];
gdjs.Untitled_32sceneCode.GDHeart2Objects1= [];
gdjs.Untitled_32sceneCode.GDHeart2Objects2= [];
gdjs.Untitled_32sceneCode.GDPlatformMidObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformMidObjects2= [];
gdjs.Untitled_32sceneCode.GDRedWoodPlankObjects1= [];
gdjs.Untitled_32sceneCode.GDRedWoodPlankObjects2= [];
gdjs.Untitled_32sceneCode.GDPlatformRightSideObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformRightSideObjects2= [];
gdjs.Untitled_32sceneCode.GDPlatformLeftSideObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformLeftSideObjects2= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDTopLeftCornerRedwoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDTopLeftCornerRedwoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDBottomLeftCornerRedwoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDBottomLeftCornerRedwoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDRedwoodBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDRedwoodBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDWoodPlankObjects1= [];
gdjs.Untitled_32sceneCode.GDWoodPlankObjects2= [];
gdjs.Untitled_32sceneCode.GDBottomRightCornerRedwoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDBottomRightCornerRedwoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDTopRightCornerRedwoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDTopRightCornerRedwoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDWoodBackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDWoodBackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDBottomLeftCornerWoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDBottomLeftCornerWoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDTopLeftCornerWoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDTopLeftCornerWoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDTopRightCornerWoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDTopRightCornerWoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDBaldPirateObjects1= [];
gdjs.Untitled_32sceneCode.GDBaldPirateObjects2= [];
gdjs.Untitled_32sceneCode.GDBigGuyObjects1= [];
gdjs.Untitled_32sceneCode.GDBigGuyObjects2= [];
gdjs.Untitled_32sceneCode.GDCaptainObjects1= [];
gdjs.Untitled_32sceneCode.GDCaptainObjects2= [];
gdjs.Untitled_32sceneCode.GDBottomRightCornerWoodBackgroundCutoutObjects1= [];
gdjs.Untitled_32sceneCode.GDBottomRightCornerWoodBackgroundCutoutObjects2= [];
gdjs.Untitled_32sceneCode.GDCucumberObjects1= [];
gdjs.Untitled_32sceneCode.GDCucumberObjects2= [];
gdjs.Untitled_32sceneCode.GDBombGuyObjects1= [];
gdjs.Untitled_32sceneCode.GDBombGuyObjects2= [];
gdjs.Untitled_32sceneCode.GDHealthBarObjects1= [];
gdjs.Untitled_32sceneCode.GDHealthBarObjects2= [];
gdjs.Untitled_32sceneCode.GDHeartObjects1= [];
gdjs.Untitled_32sceneCode.GDHeartObjects2= [];
gdjs.Untitled_32sceneCode.GDBarrelObjects1= [];
gdjs.Untitled_32sceneCode.GDBarrelObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueBottleObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueBottleObjects2= [];
gdjs.Untitled_32sceneCode.GDChairObjects1= [];
gdjs.Untitled_32sceneCode.GDChairObjects2= [];
gdjs.Untitled_32sceneCode.GDGreenBottleObjects1= [];
gdjs.Untitled_32sceneCode.GDGreenBottleObjects2= [];
gdjs.Untitled_32sceneCode.GDRedBottleObjects1= [];
gdjs.Untitled_32sceneCode.GDRedBottleObjects2= [];
gdjs.Untitled_32sceneCode.GDSkullObjects1= [];
gdjs.Untitled_32sceneCode.GDSkullObjects2= [];
gdjs.Untitled_32sceneCode.GDTableObjects1= [];
gdjs.Untitled_32sceneCode.GDTableObjects2= [];
gdjs.Untitled_32sceneCode.GDWhaleObjects1= [];
gdjs.Untitled_32sceneCode.GDWhaleObjects2= [];
gdjs.Untitled_32sceneCode.GDBombObjects1= [];
gdjs.Untitled_32sceneCode.GDBombObjects2= [];
gdjs.Untitled_32sceneCode.GDWindowsObjects1= [];
gdjs.Untitled_32sceneCode.GDWindowsObjects2= [];
gdjs.Untitled_32sceneCode.GDBigChainObjects1= [];
gdjs.Untitled_32sceneCode.GDBigChainObjects2= [];
gdjs.Untitled_32sceneCode.GDBombBarObjects1= [];
gdjs.Untitled_32sceneCode.GDBombBarObjects2= [];
gdjs.Untitled_32sceneCode.GDCandleObjects1= [];
gdjs.Untitled_32sceneCode.GDCandleObjects2= [];
gdjs.Untitled_32sceneCode.GDDoorObjects1= [];
gdjs.Untitled_32sceneCode.GDDoorObjects2= [];
gdjs.Untitled_32sceneCode.GDCannonObjects1= [];
gdjs.Untitled_32sceneCode.GDCannonObjects2= [];
gdjs.Untitled_32sceneCode.GDExclamationDialogObjects1= [];
gdjs.Untitled_32sceneCode.GDExclamationDialogObjects2= [];
gdjs.Untitled_32sceneCode.GDHeart3Objects1= [];
gdjs.Untitled_32sceneCode.GDHeart3Objects2= [];
gdjs.Untitled_32sceneCode.GDInterrogationDialogObjects1= [];
gdjs.Untitled_32sceneCode.GDInterrogationDialogObjects2= [];
gdjs.Untitled_32sceneCode.GDSmallChainObjects1= [];
gdjs.Untitled_32sceneCode.GDSmallChainObjects2= [];
gdjs.Untitled_32sceneCode.GDFallParticlesObjects1= [];
gdjs.Untitled_32sceneCode.GDFallParticlesObjects2= [];
gdjs.Untitled_32sceneCode.GDCannonBallObjects1= [];
gdjs.Untitled_32sceneCode.GDCannonBallObjects2= [];
gdjs.Untitled_32sceneCode.GDJumpParticlesObjects1= [];
gdjs.Untitled_32sceneCode.GDJumpParticlesObjects2= [];
gdjs.Untitled_32sceneCode.GDCandleLightObjects1= [];
gdjs.Untitled_32sceneCode.GDCandleLightObjects2= [];
gdjs.Untitled_32sceneCode.GDRunParticlesObjects1= [];
gdjs.Untitled_32sceneCode.GDRunParticlesObjects2= [];
gdjs.Untitled_32sceneCode.GDWindowLightObjects1= [];
gdjs.Untitled_32sceneCode.GDWindowLightObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueFloorObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueFloorObjects2= [];
gdjs.Untitled_32sceneCode.GDPenguinObjects1= [];
gdjs.Untitled_32sceneCode.GDPenguinObjects2= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects1= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPenguinObjects1Objects = Hashtable.newFrom({"Penguin": gdjs.Untitled_32sceneCode.GDPenguinObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkullObjects1Objects = Hashtable.newFrom({"Skull": gdjs.Untitled_32sceneCode.GDSkullObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Penguin"), gdjs.Untitled_32sceneCode.GDPenguinObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPenguinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPenguinObjects1[i].setPosition(792,168);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Penguin"), gdjs.Untitled_32sceneCode.GDPenguinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skull"), gdjs.Untitled_32sceneCode.GDSkullObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPenguinObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSkullObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPenguinObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPenguinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPenguinObjects1[i].setPosition(792,168);
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRangerPortraitFullBodyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRangerPortraitFullBodyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRangerPortraitObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRangerPortraitObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHeart2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDHeart2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformMidObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformMidObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedWoodPlankObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedWoodPlankObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformRightSideObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformRightSideObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformLeftSideObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformLeftSideObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTopLeftCornerRedwoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTopLeftCornerRedwoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBottomLeftCornerRedwoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBottomLeftCornerRedwoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedwoodBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedwoodBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWoodPlankObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWoodPlankObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBottomRightCornerRedwoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBottomRightCornerRedwoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTopRightCornerRedwoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTopRightCornerRedwoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWoodBackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWoodBackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBottomLeftCornerWoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBottomLeftCornerWoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTopLeftCornerWoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTopLeftCornerWoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTopRightCornerWoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTopRightCornerWoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBaldPirateObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBaldPirateObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBigGuyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBigGuyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCaptainObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCaptainObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBottomRightCornerWoodBackgroundCutoutObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBottomRightCornerWoodBackgroundCutoutObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCucumberObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCucumberObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBombGuyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBombGuyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHealthBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHeartObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDHeartObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBarrelObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBarrelObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBottleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBottleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChairObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDChairObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreenBottleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreenBottleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedBottleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedBottleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSkullObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSkullObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTableObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTableObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWhaleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWhaleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBombObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBombObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWindowsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWindowsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBigChainObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBigChainObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBombBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBombBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCandleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCandleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDoorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDoorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDExclamationDialogObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDExclamationDialogObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDHeart3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDHeart3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDInterrogationDialogObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDInterrogationDialogObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallChainObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallChainObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFallParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFallParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCannonBallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCannonBallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDJumpParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDJumpParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCandleLightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCandleLightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRunParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRunParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWindowLightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWindowLightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueFloorObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueFloorObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPenguinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPenguinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
